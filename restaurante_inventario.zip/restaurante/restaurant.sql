-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-10-2025 a las 23:26:37
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `restaurant`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admins`
--

CREATE TABLE `admins` (
  `id_admin` int(11) NOT NULL,
  `email_admin` text DEFAULT NULL,
  `rol_admin` text DEFAULT NULL,
  `permissions_admin` text DEFAULT '{}',
  `password_admin` text DEFAULT NULL,
  `token_admin` text DEFAULT NULL,
  `token_exp_admin` text DEFAULT NULL,
  `status_admin` int(11) DEFAULT 1,
  `title_admin` text DEFAULT NULL,
  `symbol_admin` text DEFAULT NULL,
  `font_admin` text DEFAULT NULL,
  `color_admin` text DEFAULT NULL,
  `back_admin` text DEFAULT NULL,
  `id_office_admin` int(11) DEFAULT 0,
  `scode_admin` text DEFAULT NULL,
  `chatgpt_admin` text DEFAULT NULL,
  `date_created_admin` date DEFAULT NULL,
  `date_updated_admin` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `admins`
--

INSERT INTO `admins` (`id_admin`, `email_admin`, `rol_admin`, `permissions_admin`, `password_admin`, `token_admin`, `token_exp_admin`, `status_admin`, `title_admin`, `symbol_admin`, `font_admin`, `color_admin`, `back_admin`, `id_office_admin`, `scode_admin`, `chatgpt_admin`, `date_created_admin`, `date_updated_admin`) VALUES
(1, 'superadmin@restaurante.com', 'superadmin', '{\"todo\":\"on\"}', '$2a$07$azybxcags23425sdg23sdeanQZqjaf6Birm2NvcYTNtJw24CsO5uq', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTk4NTg4MzUsImV4cCI6MTc1OTk0NTIzNSwiZGF0YSI6eyJpZCI6IjEiLCJlbWFpbCI6InN1cGVyYWRtaW5AcmVzdGF1cmFudGUuY29tIn19.SwO3mIZm0hJ6DQ_kvKlJTk2spyCjTC7XK2tTmn1swtk', '1759945235', 1, 'REST - BAR', '<i class=\"fa-solid fa-utensils\"></i>', '<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\r\n<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\r\n<link href=\"https://fonts.googleapis.com/css2?family=Alan+Sans:wght@300..900&display=swap\" rel=\"stylesheet\">', '#830202', 'http://cms.restaurante.com/views/assets/files/68d6eafe569fd26.png', 0, NULL, NULL, '2025-09-26', '2025-10-07 17:40:35'),
(2, 'admin@restaurante.com', 'admin', '%7B%22todo%22%3A%22on%22%7D', '$2a$07$azybxcags23425sdg23sdeanQZqjaf6Birm2NvcYTNtJw24CsO5uq', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTk1MjU4NTYsImV4cCI6MTc1OTYxMjI1NiwiZGF0YSI6eyJpZCI6IjIiLCJlbWFpbCI6ImFkbWluQHJlc3RhdXJhbnRlLmNvbSJ9fQ.gnffFZJTbvEguCoUpG3E4BYr_IWn6wvpnLVaQarYTrg', '1759612256', 1, '', '', '', '', '', 0, NULL, NULL, '2025-09-26', '2025-10-03 21:10:56'),
(3, 'miravalle@restaurante.com', 'admin', '%7B%22todo%22%3A%22on%22%7D', '$2a$07$azybxcags23425sdg23sdeanQZqjaf6Birm2NvcYTNtJw24CsO5uq', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTg5MzAwMzUsImV4cCI6MTc1OTAxNjQzNSwiZGF0YSI6eyJpZCI6IjMiLCJlbWFpbCI6Im1pcmF2YWxsZUByZXN0YXVyYW50ZS5jb20ifX0.AkkBQjVSZgQEbVlo55YIrM0htkLgWweD8-C_sx9BwWU', '1759016435', 1, '', '', '', '', '', 1, NULL, NULL, '2025-09-26', '2025-09-26 23:40:35'),
(4, 'altamira@restaurante.com', 'admin', '%7B%22todo%22%3A%22on%22%7D', '$2a$07$azybxcags23425sdg23sdeanQZqjaf6Birm2NvcYTNtJw24CsO5uq', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTg5Mjc1ODQsImV4cCI6MTc1OTAxMzk4NCwiZGF0YSI6eyJpZCI6IjQiLCJlbWFpbCI6ImFsdGFtaXJhQHJlc3RhdXJhbnRlLmNvbSJ9fQ.yBlP2JtzHnwa8RAytzj6G0iPISYw3fi8OQjshUTH0lA', '1759013984', 1, '', '', '', '', '', 2, NULL, NULL, '2025-09-26', '2025-09-26 22:59:44'),
(5, 'cumbres@restaurante.com', 'admin', '%7B%22todo%22%3A%22on%22%7D', '$2a$07$azybxcags23425sdg23sdeanQZqjaf6Birm2NvcYTNtJw24CsO5uq', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTg5MjQ5NzIsImV4cCI6MTc1OTAxMTM3MiwiZGF0YSI6eyJpZCI6IjUiLCJlbWFpbCI6ImN1bWJyZXNAcmVzdGF1cmFudGUuY29tIn19.3jf0DtkPFLOd4zIxu8Cz7aKx0P31S-rvQOhUYgJtWig', '1759011372', 1, '', '', '', '', '', 3, NULL, NULL, '2025-09-26', '2025-09-26 22:16:12'),
(6, 'inventarios_miravalle@restaurante.com', 'editor', '{\"inventario\":\"ON\",\"proveedores\":\"ON\",\"ingredientes\":\"ON\",\"productos\":\"ON\",\"compras\":\"ON\"}', '', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTk4NTg4MTMsImV4cCI6MTc1OTk0NTIxMywiZGF0YSI6eyJpZCI6IjYiLCJlbWFpbCI6ImludmVudGFyaW9zX21pcmF2YWxsZUByZXN0YXVyYW50ZS5jb20ifX0.ofgLOtVb3qFuFqvb5WL7AifC42EPNhFE1RMiit-ufHo', '1759945213', 1, '', '', '', '', '', 1, NULL, NULL, '2025-10-03', '2025-10-07 17:40:13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE `categories` (
  `id_category` int(11) NOT NULL,
  `title_category` text DEFAULT NULL,
  `img_category` text DEFAULT NULL,
  `order_category` int(11) DEFAULT 0,
  `status_category` int(11) DEFAULT 1,
  `date_created_category` date DEFAULT NULL,
  `date_updated_category` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id_category`, `title_category`, `img_category`, `order_category`, `status_category`, `date_created_category`, `date_updated_category`) VALUES
(1, 'Hamburguesas', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e1588aa431130.png', 1, 1, '2025-10-04', '2025-10-04 17:25:44'),
(2, 'Acompa%C3%B1antes', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e158b013c828.png', 2, 1, '2025-10-04', '2025-10-04 17:26:16'),
(3, 'Bebidas', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0712161d3c9.png', 3, 1, '2025-10-04', '2025-10-04 17:26:33'),
(4, 'Adiciones', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0746107cf61.png', 4, 1, '2025-10-04', '2025-10-04 17:26:53');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `columns`
--

CREATE TABLE `columns` (
  `id_column` int(11) NOT NULL,
  `id_module_column` int(11) DEFAULT 0,
  `title_column` text DEFAULT NULL,
  `alias_column` text DEFAULT NULL,
  `type_column` text DEFAULT NULL,
  `matrix_column` text DEFAULT NULL,
  `visible_column` int(11) DEFAULT 1,
  `date_created_column` date DEFAULT NULL,
  `date_updated_column` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `columns`
--

INSERT INTO `columns` (`id_column`, `id_module_column`, `title_column`, `alias_column`, `type_column`, `matrix_column`, `visible_column`, `date_created_column`, `date_updated_column`) VALUES
(1, 2, 'email_admin', 'email', 'email', '', 1, '2025-09-26', '2025-09-26 18:26:38'),
(2, 2, 'rol_admin', 'rol', 'select', 'superadmin,admin,editor', 1, '2025-09-26', '2025-09-26 18:26:38'),
(3, 2, 'permissions_admin', 'permisos', 'object', '', 1, '2025-09-26', '2025-09-26 18:26:38'),
(4, 2, 'password_admin', 'pass', 'password', '', 0, '2025-09-26', '2025-09-26 18:26:38'),
(5, 2, 'token_admin', 'token', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:38'),
(6, 2, 'token_exp_admin', 'expiración', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:38'),
(7, 2, 'status_admin', 'estado', 'boolean', '', 1, '2025-09-26', '2025-09-26 18:26:39'),
(8, 2, 'title_admin', 'título', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:39'),
(9, 2, 'symbol_admin', 'simbolo', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:39'),
(10, 2, 'font_admin', 'tipografía', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:39'),
(11, 2, 'color_admin', 'color', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:39'),
(12, 2, 'back_admin', 'fondo', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:39'),
(16, 6, 'title_office', 'Sucursal', 'text', NULL, 1, '2025-09-26', '2025-09-26 20:24:04'),
(17, 6, 'address_office', 'Dirección', 'text', NULL, 1, '2025-09-26', '2025-09-26 20:24:04'),
(18, 6, 'phone_office', 'Teléfono', 'text', NULL, 1, '2025-09-26', '2025-09-26 20:24:05'),
(19, 2, 'id_office_admin', 'Sucursal', 'relations', 'offices', 1, '2025-09-26', '2025-09-26 21:44:06'),
(20, 8, 'name_supplier', 'Proveedor', 'text', NULL, 1, '2025-10-03', '2025-10-03 21:13:44'),
(21, 8, 'phone_supplier', 'Teléfono', 'text', NULL, 1, '2025-10-03', '2025-10-03 21:13:44'),
(22, 8, 'contact_supplier', 'Contacto', 'text', NULL, 1, '2025-10-03', '2025-10-03 21:13:44'),
(23, 8, 'email_supplier', 'Email', 'email', NULL, 1, '2025-10-03', '2025-10-03 21:13:45'),
(24, 8, 'description_supplier', 'Descripción', 'textarea', NULL, 1, '2025-10-03', '2025-10-03 21:13:45'),
(25, 10, 'title_ingredient', 'Ingrediente', 'text', NULL, 1, '2025-10-03', '2025-10-03 21:30:07'),
(26, 10, 'img_ingredient', 'Imagen', 'image', NULL, 1, '2025-10-03', '2025-10-03 21:30:07'),
(27, 10, 'sku_ingredient', 'Código', 'text', NULL, 1, '2025-10-03', '2025-10-03 21:30:07'),
(28, 10, 'type_ingredient', 'Tipo Medida', 'select', 'unidad,gramos', 1, '2025-10-03', '2025-10-03 21:31:02'),
(29, 12, 'title_product', 'Producto', 'text', NULL, 1, '2025-10-03', '2025-10-03 22:40:16'),
(30, 12, 'img_product', 'Imagen', 'image', NULL, 1, '2025-10-03', '2025-10-03 22:40:17'),
(31, 12, 'sku_product', 'Código', 'text', NULL, 1, '2025-10-03', '2025-10-03 22:40:17'),
(32, 12, 'type_product', 'Tipo Medida', 'select', 'unidad,gramos,botella', 1, '2025-10-03', '2025-10-03 22:41:05'),
(33, 12, 'ingredients_product', 'Ingredientes', 'json_ingredients', NULL, 1, '2025-10-03', '2025-10-03 23:38:19'),
(34, 14, 'id_supplier_purchase', 'Proveedor', 'relations', 'suppliers', 1, '2025-10-04', '2025-10-04 16:20:04'),
(35, 14, 'type_purchase', 'Tipo', 'select', 'producto,ingrediente', 1, '2025-10-04', '2025-10-04 16:20:22'),
(36, 14, 'id_product_purchase', 'Producto', 'relations', 'products', 1, '2025-10-04', '2025-10-04 16:20:44'),
(37, 14, 'id_ingredient_purchase', 'Ingrediente', 'relations', 'ingredients', 1, '2025-10-04', '2025-10-04 16:20:38'),
(38, 14, 'measure_purchase', 'Tipo Medida', 'select', 'gramos,unidad,botella', 1, '2025-10-04', '2025-10-04 16:21:03'),
(39, 14, 'qty_purchase', 'Cantidad', 'double', NULL, 1, '2025-10-04', '2025-10-04 16:19:14'),
(40, 14, 'unit_cost_purchase', 'Costo Unitario', 'money', NULL, 1, '2025-10-04', '2025-10-04 16:19:14'),
(41, 14, 'cost_purchase', 'Costo Total', 'money', NULL, 1, '2025-10-04', '2025-10-04 16:19:14'),
(42, 14, 'stock_purchase', 'Stock', 'double', NULL, 1, '2025-10-04', '2025-10-04 16:19:15'),
(43, 14, 'id_office_purchase', 'Sucursal', 'relations', 'offices', 1, '2025-10-04', '2025-10-04 16:21:57'),
(44, 16, 'title_category', 'Categoría', 'text', NULL, 1, '2025-10-04', '2025-10-04 17:25:00'),
(45, 16, 'img_category', 'Imagen', 'image', NULL, 1, '2025-10-04', '2025-10-04 17:25:00'),
(46, 16, 'order_category', 'Orden', 'int', NULL, 1, '2025-10-04', '2025-10-04 17:25:00'),
(47, 16, 'status_category', 'Estado', 'boolean', NULL, 1, '2025-10-04', '2025-10-04 17:25:00'),
(48, 18, 'title_food', 'Comida', 'text', NULL, 1, '2025-10-04', '2025-10-04 17:38:30'),
(49, 18, 'img_food', 'Imagen', 'image', NULL, 1, '2025-10-04', '2025-10-04 17:38:30'),
(50, 18, 'products_food', 'Productos', 'json_products', NULL, 1, '2025-10-04', '2025-10-04 17:39:18'),
(51, 18, 'utility_food', 'Utilidad', 'double', NULL, 1, '2025-10-04', '2025-10-04 17:38:30'),
(52, 18, 'cost_food', 'Costo', 'money', NULL, 1, '2025-10-04', '2025-10-04 17:38:30'),
(53, 18, 'price_food', 'Precio', 'money', NULL, 1, '2025-10-04', '2025-10-04 17:38:31'),
(54, 18, 'status_food', 'Estado', 'boolean', NULL, 1, '2025-10-04', '2025-10-04 17:38:31'),
(55, 18, 'id_category_food', 'Categoría', 'relations', 'categories', 1, '2025-10-04', '2025-10-04 18:02:12'),
(56, 18, 'id_office_food', 'Sucursal', 'relations', 'offices', 1, '2025-10-04', '2025-10-04 18:02:18');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `files`
--

CREATE TABLE `files` (
  `id_file` int(11) NOT NULL,
  `id_folder_file` int(11) DEFAULT 0,
  `name_file` text DEFAULT NULL,
  `extension_file` text DEFAULT NULL,
  `type_file` text DEFAULT NULL,
  `size_file` double DEFAULT 0,
  `link_file` text DEFAULT NULL,
  `thumbnail_vimeo_file` text DEFAULT NULL,
  `id_mailchimp_file` text DEFAULT NULL,
  `id_admin_file` int(11) DEFAULT 0,
  `date_created_file` date DEFAULT NULL,
  `date_updated_file` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `files`
--

INSERT INTO `files` (`id_file`, `id_folder_file`, `name_file`, `extension_file`, `type_file`, `size_file`, `link_file`, `thumbnail_vimeo_file`, `id_mailchimp_file`, `id_admin_file`, `date_created_file`, `date_updated_file`) VALUES
(1, 1, 'couple-over-water-suite', 'jpg', 'image/jpeg', 353336, 'http://cms.restaurante.com/views/assets/files/68d6e9c8cadd316.jpg', NULL, NULL, 1, '2025-09-26', '2025-09-26 19:30:17'),
(2, 1, 'gemini-2.5-flash-image-preview (nano-banana)_El_restaurante_ya_no', 'png', 'image/png', 1764746, 'http://cms.restaurante.com/views/assets/files/68d6eafe569fd26.png', NULL, NULL, 1, '2025-09-26', '2025-09-26 19:35:26'),
(3, 1, 'huevos', 'png', 'image/png', 1703132, 'http://cms.restaurante.com/views/assets/files/68e0410bc6d4359.png', NULL, NULL, 1, '2025-10-03', '2025-10-03 21:33:05'),
(4, 1, 'harina', 'png', 'image/png', 1866804, 'http://cms.restaurante.com/views/assets/files/68e0414d3463e5.png', NULL, NULL, 1, '2025-10-03', '2025-10-03 21:34:10'),
(5, 1, 'Aguacate', 'png', 'image/png', 1566223, 'http://cms.restaurante.com/views/assets/files/68e046e7212c459.png', NULL, NULL, 1, '2025-10-03', '2025-10-03 21:58:03'),
(6, 1, 'Ajo', 'png', 'image/png', 1773659, 'http://cms.restaurante.com/views/assets/files/68e0470a5d69134.png', NULL, NULL, 1, '2025-10-03', '2025-10-03 21:58:38'),
(7, 1, 'Limones', 'png', 'image/png', 1896865, 'http://cms.restaurante.com/views/assets/files/68e0472c658e18.png', NULL, NULL, 1, '2025-10-03', '2025-10-03 21:59:12'),
(8, 1, 'Azucar', 'png', 'image/png', 1874002, 'http://cms.restaurante.com/views/assets/files/68e04758bc96652.png', NULL, NULL, 1, '2025-10-03', '2025-10-03 21:59:57'),
(9, 1, 'Pimienta', 'png', 'image/png', 2064686, 'http://cms.restaurante.com/views/assets/files/68e0476fe349f15.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:00:21'),
(10, 1, 'Sal', 'png', 'image/png', 1922393, 'http://cms.restaurante.com/views/assets/files/68e0479402bf552.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:00:55'),
(11, 1, 'tomate', 'png', 'image/png', 1844509, 'http://cms.restaurante.com/views/assets/files/68e047b4dd23924.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:01:28'),
(12, 1, 'cebolla', 'png', 'image/png', 1943987, 'http://cms.restaurante.com/views/assets/files/68e047d7740dc59.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:02:04'),
(13, 1, 'zanahoria', 'png', 'image/png', 2170489, 'http://cms.restaurante.com/views/assets/files/68e047f79366d31.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:02:35'),
(14, 1, 'repollo', 'png', 'image/png', 1547544, 'http://cms.restaurante.com/views/assets/files/68e0482c4a4fd24.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:03:29'),
(15, 1, 'Pierna de Res', 'png', 'image/png', 1947742, 'http://cms.restaurante.com/views/assets/files/68e04857a41e27.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:04:13'),
(16, 1, 'Pierna de Cerdo', 'png', 'image/png', 1921709, 'http://cms.restaurante.com/views/assets/files/68e048780b86c40.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:04:46'),
(17, 1, 'Pechuga de Pollo', 'png', 'image/png', 2082294, 'http://cms.restaurante.com/views/assets/files/68e04898c72d012.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:05:18'),
(18, 1, 'Salsa Piña', 'png', 'image/png', 1791931, 'http://cms.restaurante.com/views/assets/files/68e048b49bae140.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:06:27'),
(19, 1, 'Salsa BBQ', 'png', 'image/png', 1894033, 'http://cms.restaurante.com/views/assets/files/68e048d90783c17.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:06:22'),
(20, 1, 'Mayonesa', 'png', 'image/png', 1735466, 'http://cms.restaurante.com/views/assets/files/68e0490c631a28.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:07:14'),
(21, 1, 'Pan Hamburguesa', 'png', 'image/png', 1682620, 'http://cms.restaurante.com/views/assets/files/68e0511b9458a31.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:41:39'),
(22, 1, 'Carne Hamburguesa', 'png', 'image/png', 2229149, 'http://cms.restaurante.com/views/assets/files/68e05162e9ff942.png', NULL, NULL, 1, '2025-10-04', '2025-10-03 22:42:56'),
(23, 1, 'Queso Mozarella', 'png', 'image/png', 1449870, 'http://cms.restaurante.com/views/assets/files/68e06fa6e072f50.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 00:53:45'),
(24, 1, 'Tocineta', 'png', 'image/png', 1658244, 'http://cms.restaurante.com/views/assets/files/68e06ff0010884.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 00:53:50'),
(25, 1, 'Lechuga', 'png', 'image/png', 1471420, 'http://cms.restaurante.com/views/assets/files/68e070204a36552.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 00:53:56'),
(26, 1, 'Salsa de Tomate', 'png', 'image/png', 1739985, 'http://cms.restaurante.com/views/assets/files/68e07053c561343.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 00:54:53'),
(27, 1, 'Salsa Mostaza', 'png', 'image/png', 1801901, 'http://cms.restaurante.com/views/assets/files/68e070929165046.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 00:55:52'),
(28, 1, 'Papas Francesa', 'png', 'image/png', 2029432, 'http://cms.restaurante.com/views/assets/files/68e070e13d8595.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 00:57:10'),
(29, 1, 'Papas Criolla', 'png', 'image/png', 2183367, 'http://cms.restaurante.com/views/assets/files/68e070fa6dfe930.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 00:57:35'),
(30, 1, 'Coca Cola', 'png', 'image/png', 2244733, 'http://cms.restaurante.com/views/assets/files/68e0712161d3c9.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 00:58:13'),
(31, 1, 'Postobón', 'png', 'image/png', 2295633, 'http://cms.restaurante.com/views/assets/files/68e0714c3328452.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 00:58:58'),
(32, 1, 'Pollo BBQ', 'png', 'image/png', 1737854, 'http://cms.restaurante.com/views/assets/files/68e0716b7259823.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 00:59:28'),
(33, 1, 'Guacamole', 'png', 'image/png', 1608247, 'http://cms.restaurante.com/views/assets/files/68e0746107cf61.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 01:12:05'),
(34, 1, 'Ensalada dulce', 'png', 'image/png', 1769855, 'http://cms.restaurante.com/views/assets/files/68e074a2a1f0a6.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 01:13:11'),
(35, 1, 'Aros de Cebolla', 'png', 'image/png', 1696562, 'http://cms.restaurante.com/views/assets/files/68e0753eeedca42.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 01:15:47'),
(36, 1, 'zumo de limón', 'png', 'image/png', 1957625, 'http://cms.restaurante.com/views/assets/files/68e0764077df60.png', NULL, NULL, 6, '2025-10-04', '2025-10-04 01:20:07'),
(37, 1, 'Hamburguesa', 'png', 'image/png', 2628790, 'http://cms.restaurante.com/views/assets/files/68e1588aa431130.png', NULL, NULL, 1, '2025-10-04', '2025-10-04 17:25:37'),
(38, 1, 'Papas Francesa', 'png', 'image/png', 1665876, 'http://cms.restaurante.com/views/assets/files/68e158b013c828.png', NULL, NULL, 1, '2025-10-04', '2025-10-04 17:26:13'),
(39, 1, 'Hamburguesa Clásica', 'png', 'image/png', 1638960, 'http://cms.restaurante.com/views/assets/files/68e15dc6cc29150.png', NULL, NULL, 1, '2025-10-04', '2025-10-04 17:47:57'),
(40, 1, 'Mexicana', 'png', 'image/png', 2537286, 'http://cms.restaurante.com/views/assets/files/68e57fa27705122.png', NULL, NULL, 1, '2025-10-07', '2025-10-07 21:01:27'),
(41, 1, 'Pollo BBQ', 'png', 'image/png', 2525027, 'http://cms.restaurante.com/views/assets/files/68e58027d784635.png', NULL, NULL, 1, '2025-10-07', '2025-10-07 21:03:42'),
(42, 1, 'Papas con Salsa', 'png', 'image/png', 1599042, 'http://cms.restaurante.com/views/assets/files/68e5808e85def18.png', NULL, NULL, 1, '2025-10-07', '2025-10-07 21:05:25'),
(43, 1, 'Criollas con Limón', 'png', 'image/png', 2023137, 'http://cms.restaurante.com/views/assets/files/68e580f0efb6856.png', NULL, NULL, 1, '2025-10-07', '2025-10-07 21:07:03'),
(45, 1, 'Aros de Cebolla con Mayonesa', 'png', 'image/png', 1916532, 'http://cms.restaurante.com/views/assets/files/68e5815789c5539.png', NULL, NULL, 1, '2025-10-07', '2025-10-07 21:08:46');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `folders`
--

CREATE TABLE `folders` (
  `id_folder` int(11) NOT NULL,
  `name_folder` text DEFAULT NULL,
  `size_folder` text DEFAULT NULL,
  `total_folder` double DEFAULT 0,
  `max_upload_folder` text DEFAULT NULL,
  `url_folder` text DEFAULT NULL,
  `keys_folder` text DEFAULT NULL,
  `date_created_folder` date DEFAULT NULL,
  `date_updated_folder` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `folders`
--

INSERT INTO `folders` (`id_folder`, `name_folder`, `size_folder`, `total_folder`, `max_upload_folder`, `url_folder`, `keys_folder`, `date_created_folder`, `date_updated_folder`) VALUES
(1, 'Server', '200000000000', 81756697, '500000000', 'http://cms.restaurante.com', NULL, '2025-09-26', '2025-10-07 21:08:55');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `foods`
--

CREATE TABLE `foods` (
  `id_food` int(11) NOT NULL,
  `title_food` text DEFAULT NULL,
  `img_food` text DEFAULT NULL,
  `products_food` text DEFAULT '[]',
  `utility_food` double DEFAULT 0,
  `cost_food` double DEFAULT 0,
  `price_food` double DEFAULT 0,
  `status_food` int(11) DEFAULT 1,
  `id_category_food` int(11) DEFAULT 0,
  `id_office_food` int(11) DEFAULT 0,
  `date_created_food` date DEFAULT NULL,
  `date_updated_food` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `foods`
--

INSERT INTO `foods` (`id_food`, `title_food`, `img_food`, `products_food`, `utility_food`, `cost_food`, `price_food`, `status_food`, `id_category_food`, `id_office_food`, `date_created_food`, `date_updated_food`) VALUES
(1, 'Hamburguesa Clásica', 'http://cms.restaurante.com/views/assets/files/68e15dc6cc29150.png', '[{\"descripcion\":\"Pan Hamburguesa^PKU_001^unidad\",\"sku\":\"PKU_001\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Carne Hamburguesa^PKU_002^gramos\",\"sku\":\"PKU_002\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Queso Mozarella^SKU_003^unidad\",\"sku\":\"SKU_003\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Salsa de Tomate^SKU_006^gramos\",\"sku\":\"SKU_006\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Salsa Mayonesa^SKU_007^gramos\",\"sku\":\"SKU_007\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Salsa Mostaza^SKU_008^gramos\",\"sku\":\"SKU_008\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Lechuga^SKU_005^gramos\",\"sku\":\"SKU_005\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Tomate^SKU_009^unidad\",\"sku\":\"SKU_009\",\"medida\":\"unidad\",\"cantidad\":\"0.2\"},{\"descripcion\":\"Cebolla^SKU_010^unidad\",\"sku\":\"SKU_010\",\"medida\":\"unidad\",\"cantidad\":\"0.2\"}]', 200, 102.79, 308.37, 1, 1, 1, '2025-10-04', '2025-10-07 20:33:43'),
(2, 'Hamburguesa Americana', 'http://cms.restaurante.com/views/assets/files/68e1588aa431130.png', '[{\"descripcion\":\"Pan Hamburguesa^PKU_001^unidad\",\"sku\":\"PKU_001\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Carne Hamburguesa^PKU_002^unidad\",\"sku\":\"PKU_002\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Queso Mozarella^SKU_003^unidad\",\"sku\":\"SKU_003\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Salsa de Tomate^SKU_006^gramos\",\"sku\":\"SKU_006\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Salsa Mayonesa^SKU_007^gramos\",\"sku\":\"SKU_007\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Salsa Mostaza^SKU_008^gramos\",\"sku\":\"SKU_008\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Lechuga^SKU_005^gramos\",\"sku\":\"SKU_005\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Tomate^SKU_009^unidad\",\"sku\":\"SKU_009\",\"medida\":\"unidad\",\"cantidad\":\"0.2\"},{\"descripcion\":\"Cebolla^SKU_010^unidad\",\"sku\":\"SKU_010\",\"medida\":\"unidad\",\"cantidad\":\"0.2\"},{\"descripcion\":\"Tocineta^SKU_004^unidad\",\"sku\":\"SKU_004\",\"medida\":\"unidad\",\"cantidad\":\"1\"}]', 200, 103.09, 309.27, 1, 1, 1, '2025-10-07', '2025-10-07 21:00:26'),
(3, 'Hamburguesa+Mexicana', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e57fa27705122.png', '%5B%7B%22descripcion%22%3A%22Pan%2BHamburguesa%5EPKU_001%5Eunidad%22%2C%22sku%22%3A%22PKU_001%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Carne%2BHamburguesa%5EPKU_002%5Eunidad%22%2C%22sku%22%3A%22PKU_002%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Queso%2BMozarella%5ESKU_003%5Eunidad%22%2C%22sku%22%3A%22SKU_003%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2Bde%2BTomate%5ESKU_006%5Egramos%22%2C%22sku%22%3A%22SKU_006%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMayonesa%5ESKU_007%5Egramos%22%2C%22sku%22%3A%22SKU_007%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMostaza%5ESKU_008%5Egramos%22%2C%22sku%22%3A%22SKU_008%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Lechuga%5ESKU_005%5Egramos%22%2C%22sku%22%3A%22SKU_005%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Tomate%5ESKU_009%5Eunidad%22%2C%22sku%22%3A%22SKU_009%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.2%22%7D%2C%7B%22descripcion%22%3A%22Cebolla%5ESKU_010%5Eunidad%22%2C%22sku%22%3A%22SKU_010%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.2%22%7D%2C%7B%22descripcion%22%3A%22Tocineta%5ESKU_004%5Eunidad%22%2C%22sku%22%3A%22SKU_004%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Guacamole%5ESKU_016%5Egramos%22%2C%22sku%22%3A%22SKU_016%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 103.74, 311.22, 1, 1, 1, '2025-10-07', '2025-10-07 21:02:04'),
(4, 'Hamburguesa+Pollo+BBQ', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e58027d784635.png', '%5B%7B%22descripcion%22%3A%22Pan%2BHamburguesa%5EPKU_001%5Eunidad%22%2C%22sku%22%3A%22PKU_001%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Pollo+a+la+BBQ%5ESKU_015%5Egramos%22%2C%22sku%22%3A%22SKU_015%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Queso%2BMozarella%5ESKU_003%5Eunidad%22%2C%22sku%22%3A%22SKU_003%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2Bde%2BTomate%5ESKU_006%5Egramos%22%2C%22sku%22%3A%22SKU_006%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMayonesa%5ESKU_007%5Egramos%22%2C%22sku%22%3A%22SKU_007%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMostaza%5ESKU_008%5Egramos%22%2C%22sku%22%3A%22SKU_008%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Lechuga%5ESKU_005%5Egramos%22%2C%22sku%22%3A%22SKU_005%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Tomate%5ESKU_009%5Eunidad%22%2C%22sku%22%3A%22SKU_009%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.2%22%7D%2C%7B%22descripcion%22%3A%22Cebolla%5ESKU_010%5Eunidad%22%2C%22sku%22%3A%22SKU_010%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.2%22%7D%2C%7B%22descripcion%22%3A%22Tocineta%5ESKU_004%5Eunidad%22%2C%22sku%22%3A%22SKU_004%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Ensalada%2BDulce%2BRepollo%5ESKU_017%5Egramos%22%2C%22sku%22%3A%22SKU_017%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 94.45, 283.36, 1, 1, 1, '2025-10-07', '2025-10-07 21:04:29'),
(5, 'Papas+a+la+Francesa+con+Salsa', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e5808e85def18.png', '%5B%7B%22descripcion%22%3A%22Papas%2BFrancesa%5ESKU_011%5Egramos%22%2C%22sku%22%3A%22SKU_011%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%22150%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2Bde%2BTomate%5ESKU_006%5Egramos%22%2C%22sku%22%3A%22SKU_006%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%223%22%7D%5D', 200, 90.9, 272.7, 1, 2, 1, '2025-10-07', '2025-10-07 21:06:15'),
(6, 'Papas+Criollas+con+Zumo+de+Lim%C3%B3n', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e580f0efb6856.png', '%5B%7B%22descripcion%22%3A%22Papas%2BCriolla%5ESKU_012%5Egramos%22%2C%22sku%22%3A%22SKU_012%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%22150%22%7D%2C%7B%22descripcion%22%3A%22Zumo%2Bde%2Blim%25C3%25B3n%5ESKU_019%5Eunidad%22%2C%22sku%22%3A%22SKU_019%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 90.75, 272.25, 1, 2, 1, '2025-10-07', '2025-10-07 21:07:27'),
(7, 'Aros de Cebolla Apanados con Mayonesa', 'http://cms.restaurante.com/views/assets/files/68e5815789c5539.png', '[{\"descripcion\":\"Aros de Cebolla Apanados^SKU_018^unidad\",\"sku\":\"SKU_018\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Salsa+Mayonesa^SKU_007^gramos\",\"sku\":\"SKU_007\",\"medida\":\"gramos\",\"cantidad\":\"5\"}]', 200, 4.33, 12.98, 1, 2, 1, '2025-10-07', '2025-10-07 21:11:23'),
(8, 'Bebidas+Marca+Coca+Cola', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0712161d3c9.png', '%5B%7B%22descripcion%22%3A%22Bebida+Marca+Coca+Cola%5ESKU_013%5Ebotella%22%2C%22sku%22%3A%22SKU_013%22%2C%22medida%22%3A%22botella%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 0.16, 0.48, 1, 3, 1, '2025-10-07', '2025-10-07 21:14:08'),
(9, 'Bebidas+Marca+Postob%C3%B3n', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0714c3328452.png', '%5B%7B%22descripcion%22%3A%22Bebida+Marca+Coca+Cola%5ESKU_013%5Ebotella%22%2C%22sku%22%3A%22SKU_013%22%2C%22medida%22%3A%22botella%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 0.16, 0.48, 1, 3, 1, '2025-10-07', '2025-10-07 21:16:01'),
(10, 'Adición de Queso Mozarella', 'http://cms.restaurante.com/views/assets/files/68e06fa6e072f50.png', '[{\"descripcion\":\"Queso+Mozarella^SKU_003^unidad\",\"sku\":\"SKU_003\",\"medida\":\"unidad\",\"cantidad\":\"1\"}]', 200, 0.5, 1.5, 1, 4, 1, '2025-10-07', '2025-10-07 21:17:02'),
(11, 'Adici%C3%B3n+de+Tocineta', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e06ff0010884.png', '%5B%7B%22descripcion%22%3A%22Tocineta%5ESKU_004%5Eunidad%22%2C%22sku%22%3A%22SKU_004%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 0.3, 0.9, 1, 4, 1, '2025-10-07', '2025-10-07 21:17:39'),
(12, 'Adici%C3%B3n+de+Guacamole', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0746107cf61.png', '%5B%7B%22descripcion%22%3A%22Guacamole%5ESKU_016%5Egramos%22%2C%22sku%22%3A%22SKU_016%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%2210%22%7D%5D', 200, 0.65, 1.95, 1, 4, 1, '2025-10-07', '2025-10-07 21:18:54'),
(13, 'Adici%C3%B3n+de+Ensalada+Dulce', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e074a2a1f0a6.png', '%5B%7B%22descripcion%22%3A%22Ensalada%2BDulce%2BRepollo%5ESKU_017%5Egramos%22%2C%22sku%22%3A%22SKU_017%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%2210%22%7D%5D', 200, 0.61, 1.84, 1, 4, 1, '2025-10-07', '2025-10-07 21:19:41'),
(14, 'Hamburguesa Clásica', 'http://cms.restaurante.com/views/assets/files/68e15dc6cc29150.png', '[{\"descripcion\":\"Pan Hamburguesa^PKU_001^unidad\",\"sku\":\"PKU_001\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Carne Hamburguesa^PKU_002^gramos\",\"sku\":\"PKU_002\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Queso Mozarella^SKU_003^unidad\",\"sku\":\"SKU_003\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Salsa de Tomate^SKU_006^gramos\",\"sku\":\"SKU_006\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Salsa Mayonesa^SKU_007^gramos\",\"sku\":\"SKU_007\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Salsa Mostaza^SKU_008^gramos\",\"sku\":\"SKU_008\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Lechuga^SKU_005^gramos\",\"sku\":\"SKU_005\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Tomate^SKU_009^unidad\",\"sku\":\"SKU_009\",\"medida\":\"unidad\",\"cantidad\":\"0.2\"},{\"descripcion\":\"Cebolla^SKU_010^unidad\",\"sku\":\"SKU_010\",\"medida\":\"unidad\",\"cantidad\":\"0.2\"}]', 200, 102.79, 308.37, 1, 1, 2, '2025-10-04', '2025-10-08 01:33:43'),
(15, 'Hamburguesa Americana', 'http://cms.restaurante.com/views/assets/files/68e1588aa431130.png', '[{\"descripcion\":\"Pan Hamburguesa^PKU_001^unidad\",\"sku\":\"PKU_001\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Carne Hamburguesa^PKU_002^unidad\",\"sku\":\"PKU_002\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Queso Mozarella^SKU_003^unidad\",\"sku\":\"SKU_003\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Salsa de Tomate^SKU_006^gramos\",\"sku\":\"SKU_006\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Salsa Mayonesa^SKU_007^gramos\",\"sku\":\"SKU_007\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Salsa Mostaza^SKU_008^gramos\",\"sku\":\"SKU_008\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Lechuga^SKU_005^gramos\",\"sku\":\"SKU_005\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Tomate^SKU_009^unidad\",\"sku\":\"SKU_009\",\"medida\":\"unidad\",\"cantidad\":\"0.2\"},{\"descripcion\":\"Cebolla^SKU_010^unidad\",\"sku\":\"SKU_010\",\"medida\":\"unidad\",\"cantidad\":\"0.2\"},{\"descripcion\":\"Tocineta^SKU_004^unidad\",\"sku\":\"SKU_004\",\"medida\":\"unidad\",\"cantidad\":\"1\"}]', 200, 103.09, 309.27, 1, 1, 1, '2025-10-07', '2025-10-08 02:00:26'),
(16, 'Hamburguesa+Mexicana', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e57fa27705122.png', '%5B%7B%22descripcion%22%3A%22Pan%2BHamburguesa%5EPKU_001%5Eunidad%22%2C%22sku%22%3A%22PKU_001%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Carne%2BHamburguesa%5EPKU_002%5Eunidad%22%2C%22sku%22%3A%22PKU_002%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Queso%2BMozarella%5ESKU_003%5Eunidad%22%2C%22sku%22%3A%22SKU_003%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2Bde%2BTomate%5ESKU_006%5Egramos%22%2C%22sku%22%3A%22SKU_006%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMayonesa%5ESKU_007%5Egramos%22%2C%22sku%22%3A%22SKU_007%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMostaza%5ESKU_008%5Egramos%22%2C%22sku%22%3A%22SKU_008%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Lechuga%5ESKU_005%5Egramos%22%2C%22sku%22%3A%22SKU_005%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Tomate%5ESKU_009%5Eunidad%22%2C%22sku%22%3A%22SKU_009%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.2%22%7D%2C%7B%22descripcion%22%3A%22Cebolla%5ESKU_010%5Eunidad%22%2C%22sku%22%3A%22SKU_010%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.2%22%7D%2C%7B%22descripcion%22%3A%22Tocineta%5ESKU_004%5Eunidad%22%2C%22sku%22%3A%22SKU_004%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Guacamole%5ESKU_016%5Egramos%22%2C%22sku%22%3A%22SKU_016%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 103.74, 311.22, 1, 1, 2, '2025-10-07', '2025-10-08 02:02:04'),
(17, 'Hamburguesa+Pollo+BBQ', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e58027d784635.png', '%5B%7B%22descripcion%22%3A%22Pan%2BHamburguesa%5EPKU_001%5Eunidad%22%2C%22sku%22%3A%22PKU_001%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Pollo+a+la+BBQ%5ESKU_015%5Egramos%22%2C%22sku%22%3A%22SKU_015%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Queso%2BMozarella%5ESKU_003%5Eunidad%22%2C%22sku%22%3A%22SKU_003%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2Bde%2BTomate%5ESKU_006%5Egramos%22%2C%22sku%22%3A%22SKU_006%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMayonesa%5ESKU_007%5Egramos%22%2C%22sku%22%3A%22SKU_007%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMostaza%5ESKU_008%5Egramos%22%2C%22sku%22%3A%22SKU_008%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Lechuga%5ESKU_005%5Egramos%22%2C%22sku%22%3A%22SKU_005%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Tomate%5ESKU_009%5Eunidad%22%2C%22sku%22%3A%22SKU_009%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.2%22%7D%2C%7B%22descripcion%22%3A%22Cebolla%5ESKU_010%5Eunidad%22%2C%22sku%22%3A%22SKU_010%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.2%22%7D%2C%7B%22descripcion%22%3A%22Tocineta%5ESKU_004%5Eunidad%22%2C%22sku%22%3A%22SKU_004%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Ensalada%2BDulce%2BRepollo%5ESKU_017%5Egramos%22%2C%22sku%22%3A%22SKU_017%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 94.45, 283.36, 1, 1, 2, '2025-10-07', '2025-10-08 02:04:29'),
(18, 'Papas+a+la+Francesa+con+Salsa', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e5808e85def18.png', '%5B%7B%22descripcion%22%3A%22Papas%2BFrancesa%5ESKU_011%5Egramos%22%2C%22sku%22%3A%22SKU_011%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%22150%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2Bde%2BTomate%5ESKU_006%5Egramos%22%2C%22sku%22%3A%22SKU_006%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%223%22%7D%5D', 200, 90.9, 272.7, 1, 2, 2, '2025-10-07', '2025-10-08 02:06:15'),
(19, 'Papas+Criollas+con+Zumo+de+Lim%C3%B3n', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e580f0efb6856.png', '%5B%7B%22descripcion%22%3A%22Papas%2BCriolla%5ESKU_012%5Egramos%22%2C%22sku%22%3A%22SKU_012%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%22150%22%7D%2C%7B%22descripcion%22%3A%22Zumo%2Bde%2Blim%25C3%25B3n%5ESKU_019%5Eunidad%22%2C%22sku%22%3A%22SKU_019%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 90.75, 272.25, 1, 2, 2, '2025-10-07', '2025-10-08 02:07:27'),
(20, 'Aros de Cebolla Apanados con Mayonesa', 'http://cms.restaurante.com/views/assets/files/68e5815789c5539.png', '[{\"descripcion\":\"Aros de Cebolla Apanados^SKU_018^unidad\",\"sku\":\"SKU_018\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Salsa+Mayonesa^SKU_007^gramos\",\"sku\":\"SKU_007\",\"medida\":\"gramos\",\"cantidad\":\"5\"}]', 200, 4.33, 12.98, 1, 2, 2, '2025-10-07', '2025-10-08 02:11:23'),
(21, 'Bebidas+Marca+Coca+Cola', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0712161d3c9.png', '%5B%7B%22descripcion%22%3A%22Bebida+Marca+Coca+Cola%5ESKU_013%5Ebotella%22%2C%22sku%22%3A%22SKU_013%22%2C%22medida%22%3A%22botella%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 0.16, 0.48, 1, 3, 2, '2025-10-07', '2025-10-08 02:14:08'),
(22, 'Bebidas+Marca+Postob%C3%B3n', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0714c3328452.png', '%5B%7B%22descripcion%22%3A%22Bebida+Marca+Coca+Cola%5ESKU_013%5Ebotella%22%2C%22sku%22%3A%22SKU_013%22%2C%22medida%22%3A%22botella%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 0.16, 0.48, 1, 3, 2, '2025-10-07', '2025-10-08 02:16:01'),
(23, 'Adición de Queso Mozarella', 'http://cms.restaurante.com/views/assets/files/68e06fa6e072f50.png', '[{\"descripcion\":\"Queso+Mozarella^SKU_003^unidad\",\"sku\":\"SKU_003\",\"medida\":\"unidad\",\"cantidad\":\"1\"}]', 200, 0.5, 1.5, 1, 4, 2, '2025-10-07', '2025-10-08 02:17:02'),
(24, 'Adici%C3%B3n+de+Tocineta', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e06ff0010884.png', '%5B%7B%22descripcion%22%3A%22Tocineta%5ESKU_004%5Eunidad%22%2C%22sku%22%3A%22SKU_004%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 0.3, 0.9, 1, 4, 2, '2025-10-07', '2025-10-08 02:17:39'),
(25, 'Adici%C3%B3n+de+Guacamole', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0746107cf61.png', '%5B%7B%22descripcion%22%3A%22Guacamole%5ESKU_016%5Egramos%22%2C%22sku%22%3A%22SKU_016%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%2210%22%7D%5D', 200, 0.65, 1.95, 1, 4, 2, '2025-10-07', '2025-10-08 02:18:54'),
(26, 'Adici%C3%B3n+de+Ensalada+Dulce', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e074a2a1f0a6.png', '%5B%7B%22descripcion%22%3A%22Ensalada%2BDulce%2BRepollo%5ESKU_017%5Egramos%22%2C%22sku%22%3A%22SKU_017%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%2210%22%7D%5D', 200, 0.61, 1.84, 1, 4, 2, '2025-10-07', '2025-10-08 02:19:41'),
(27, 'Hamburguesa Clásica', 'http://cms.restaurante.com/views/assets/files/68e15dc6cc29150.png', '[{\"descripcion\":\"Pan Hamburguesa^PKU_001^unidad\",\"sku\":\"PKU_001\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Carne Hamburguesa^PKU_002^gramos\",\"sku\":\"PKU_002\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Queso Mozarella^SKU_003^unidad\",\"sku\":\"SKU_003\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Salsa de Tomate^SKU_006^gramos\",\"sku\":\"SKU_006\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Salsa Mayonesa^SKU_007^gramos\",\"sku\":\"SKU_007\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Salsa Mostaza^SKU_008^gramos\",\"sku\":\"SKU_008\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Lechuga^SKU_005^gramos\",\"sku\":\"SKU_005\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Tomate^SKU_009^unidad\",\"sku\":\"SKU_009\",\"medida\":\"unidad\",\"cantidad\":\"0.2\"},{\"descripcion\":\"Cebolla^SKU_010^unidad\",\"sku\":\"SKU_010\",\"medida\":\"unidad\",\"cantidad\":\"0.2\"}]', 200, 102.79, 308.37, 1, 1, 3, '2025-10-04', '2025-10-08 01:33:43'),
(28, 'Hamburguesa Americana', 'http://cms.restaurante.com/views/assets/files/68e1588aa431130.png', '[{\"descripcion\":\"Pan Hamburguesa^PKU_001^unidad\",\"sku\":\"PKU_001\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Carne Hamburguesa^PKU_002^unidad\",\"sku\":\"PKU_002\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Queso Mozarella^SKU_003^unidad\",\"sku\":\"SKU_003\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Salsa de Tomate^SKU_006^gramos\",\"sku\":\"SKU_006\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Salsa Mayonesa^SKU_007^gramos\",\"sku\":\"SKU_007\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Salsa Mostaza^SKU_008^gramos\",\"sku\":\"SKU_008\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Lechuga^SKU_005^gramos\",\"sku\":\"SKU_005\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Tomate^SKU_009^unidad\",\"sku\":\"SKU_009\",\"medida\":\"unidad\",\"cantidad\":\"0.2\"},{\"descripcion\":\"Cebolla^SKU_010^unidad\",\"sku\":\"SKU_010\",\"medida\":\"unidad\",\"cantidad\":\"0.2\"},{\"descripcion\":\"Tocineta^SKU_004^unidad\",\"sku\":\"SKU_004\",\"medida\":\"unidad\",\"cantidad\":\"1\"}]', 200, 103.09, 309.27, 1, 1, 1, '2025-10-07', '2025-10-08 02:00:26'),
(29, 'Hamburguesa+Mexicana', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e57fa27705122.png', '%5B%7B%22descripcion%22%3A%22Pan%2BHamburguesa%5EPKU_001%5Eunidad%22%2C%22sku%22%3A%22PKU_001%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Carne%2BHamburguesa%5EPKU_002%5Eunidad%22%2C%22sku%22%3A%22PKU_002%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Queso%2BMozarella%5ESKU_003%5Eunidad%22%2C%22sku%22%3A%22SKU_003%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2Bde%2BTomate%5ESKU_006%5Egramos%22%2C%22sku%22%3A%22SKU_006%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMayonesa%5ESKU_007%5Egramos%22%2C%22sku%22%3A%22SKU_007%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMostaza%5ESKU_008%5Egramos%22%2C%22sku%22%3A%22SKU_008%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Lechuga%5ESKU_005%5Egramos%22%2C%22sku%22%3A%22SKU_005%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Tomate%5ESKU_009%5Eunidad%22%2C%22sku%22%3A%22SKU_009%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.2%22%7D%2C%7B%22descripcion%22%3A%22Cebolla%5ESKU_010%5Eunidad%22%2C%22sku%22%3A%22SKU_010%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.2%22%7D%2C%7B%22descripcion%22%3A%22Tocineta%5ESKU_004%5Eunidad%22%2C%22sku%22%3A%22SKU_004%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Guacamole%5ESKU_016%5Egramos%22%2C%22sku%22%3A%22SKU_016%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 103.74, 311.22, 1, 1, 3, '2025-10-07', '2025-10-08 02:02:04'),
(30, 'Hamburguesa+Pollo+BBQ', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e58027d784635.png', '%5B%7B%22descripcion%22%3A%22Pan%2BHamburguesa%5EPKU_001%5Eunidad%22%2C%22sku%22%3A%22PKU_001%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Pollo+a+la+BBQ%5ESKU_015%5Egramos%22%2C%22sku%22%3A%22SKU_015%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Queso%2BMozarella%5ESKU_003%5Eunidad%22%2C%22sku%22%3A%22SKU_003%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2Bde%2BTomate%5ESKU_006%5Egramos%22%2C%22sku%22%3A%22SKU_006%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMayonesa%5ESKU_007%5Egramos%22%2C%22sku%22%3A%22SKU_007%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMostaza%5ESKU_008%5Egramos%22%2C%22sku%22%3A%22SKU_008%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Lechuga%5ESKU_005%5Egramos%22%2C%22sku%22%3A%22SKU_005%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Tomate%5ESKU_009%5Eunidad%22%2C%22sku%22%3A%22SKU_009%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.2%22%7D%2C%7B%22descripcion%22%3A%22Cebolla%5ESKU_010%5Eunidad%22%2C%22sku%22%3A%22SKU_010%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.2%22%7D%2C%7B%22descripcion%22%3A%22Tocineta%5ESKU_004%5Eunidad%22%2C%22sku%22%3A%22SKU_004%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Ensalada%2BDulce%2BRepollo%5ESKU_017%5Egramos%22%2C%22sku%22%3A%22SKU_017%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 94.45, 283.36, 1, 1, 3, '2025-10-07', '2025-10-08 02:04:29'),
(31, 'Papas+a+la+Francesa+con+Salsa', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e5808e85def18.png', '%5B%7B%22descripcion%22%3A%22Papas%2BFrancesa%5ESKU_011%5Egramos%22%2C%22sku%22%3A%22SKU_011%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%22150%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2Bde%2BTomate%5ESKU_006%5Egramos%22%2C%22sku%22%3A%22SKU_006%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%223%22%7D%5D', 200, 90.9, 272.7, 1, 2, 3, '2025-10-07', '2025-10-08 02:06:15'),
(32, 'Papas+Criollas+con+Zumo+de+Lim%C3%B3n', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e580f0efb6856.png', '%5B%7B%22descripcion%22%3A%22Papas%2BCriolla%5ESKU_012%5Egramos%22%2C%22sku%22%3A%22SKU_012%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%22150%22%7D%2C%7B%22descripcion%22%3A%22Zumo%2Bde%2Blim%25C3%25B3n%5ESKU_019%5Eunidad%22%2C%22sku%22%3A%22SKU_019%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 90.75, 272.25, 1, 2, 3, '2025-10-07', '2025-10-08 02:07:27'),
(33, 'Aros de Cebolla Apanados con Mayonesa', 'http://cms.restaurante.com/views/assets/files/68e5815789c5539.png', '[{\"descripcion\":\"Aros de Cebolla Apanados^SKU_018^unidad\",\"sku\":\"SKU_018\",\"medida\":\"unidad\",\"cantidad\":\"1\"},{\"descripcion\":\"Salsa+Mayonesa^SKU_007^gramos\",\"sku\":\"SKU_007\",\"medida\":\"gramos\",\"cantidad\":\"5\"}]', 200, 4.33, 12.98, 1, 2, 3, '2025-10-07', '2025-10-08 02:11:23'),
(34, 'Bebidas+Marca+Coca+Cola', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0712161d3c9.png', '%5B%7B%22descripcion%22%3A%22Bebida+Marca+Coca+Cola%5ESKU_013%5Ebotella%22%2C%22sku%22%3A%22SKU_013%22%2C%22medida%22%3A%22botella%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 0.16, 0.48, 1, 3, 3, '2025-10-07', '2025-10-08 02:14:08'),
(35, 'Bebidas+Marca+Postob%C3%B3n', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0714c3328452.png', '%5B%7B%22descripcion%22%3A%22Bebida+Marca+Coca+Cola%5ESKU_013%5Ebotella%22%2C%22sku%22%3A%22SKU_013%22%2C%22medida%22%3A%22botella%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 0.16, 0.48, 1, 3, 3, '2025-10-07', '2025-10-08 02:16:01'),
(36, 'Adición de Queso Mozarella', 'http://cms.restaurante.com/views/assets/files/68e06fa6e072f50.png', '[{\"descripcion\":\"Queso+Mozarella^SKU_003^unidad\",\"sku\":\"SKU_003\",\"medida\":\"unidad\",\"cantidad\":\"1\"}]', 200, 0.5, 1.5, 1, 4, 3, '2025-10-07', '2025-10-08 02:17:02'),
(37, 'Adici%C3%B3n+de+Tocineta', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e06ff0010884.png', '%5B%7B%22descripcion%22%3A%22Tocineta%5ESKU_004%5Eunidad%22%2C%22sku%22%3A%22SKU_004%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%5D', 200, 0.3, 0.9, 1, 4, 3, '2025-10-07', '2025-10-08 02:17:39'),
(38, 'Adici%C3%B3n+de+Guacamole', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0746107cf61.png', '%5B%7B%22descripcion%22%3A%22Guacamole%5ESKU_016%5Egramos%22%2C%22sku%22%3A%22SKU_016%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%2210%22%7D%5D', 200, 0.65, 1.95, 1, 4, 3, '2025-10-07', '2025-10-08 02:18:54'),
(39, 'Adici%C3%B3n+de+Ensalada+Dulce', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e074a2a1f0a6.png', '%5B%7B%22descripcion%22%3A%22Ensalada%2BDulce%2BRepollo%5ESKU_017%5Egramos%22%2C%22sku%22%3A%22SKU_017%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%2210%22%7D%5D', 200, 0.61, 1.84, 1, 4, 3, '2025-10-07', '2025-10-08 02:19:41');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingredients`
--

CREATE TABLE `ingredients` (
  `id_ingredient` int(11) NOT NULL,
  `title_ingredient` text DEFAULT NULL,
  `img_ingredient` text DEFAULT NULL,
  `sku_ingredient` text DEFAULT NULL,
  `type_ingredient` text DEFAULT NULL,
  `date_created_ingredient` date DEFAULT NULL,
  `date_updated_ingredient` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ingredients`
--

INSERT INTO `ingredients` (`id_ingredient`, `title_ingredient`, `img_ingredient`, `sku_ingredient`, `type_ingredient`, `date_created_ingredient`, `date_updated_ingredient`) VALUES
(1, 'Huevos', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0410bc6d4359.png', 'IKU_001', 'unidad', '2025-10-03', '2025-10-03 21:33:25'),
(2, 'Harina+para+Apanar', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0414d3463e5.png', 'IKU_002', 'gramos', '2025-10-03', '2025-10-03 21:34:20'),
(3, 'Aguacate', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e046e7212c459.png', 'IKU_003', 'unidad', '2025-10-03', '2025-10-03 21:58:12'),
(4, 'Ajo', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0470a5d69134.png', 'IKU_004', 'unidad', '2025-10-03', '2025-10-03 21:58:50'),
(5, 'Limones', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0472c658e18.png', 'IKU_005', 'unidad', '2025-10-03', '2025-10-03 21:59:16'),
(6, 'Azucar', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e04758bc96652.png', 'IKU_006', 'gramos', '2025-10-03', '2025-10-03 22:00:00'),
(7, 'Pimienta', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0476fe349f15.png', 'IKU_007', 'gramos', '2025-10-03', '2025-10-03 22:00:31'),
(8, 'Sal', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0479402bf552.png', 'IKU_008', 'gramos', '2025-10-03', '2025-10-03 22:01:01'),
(9, 'Tomate', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e047b4dd23924.png', 'IKU_009', 'unidad', '2025-10-03', '2025-10-03 22:01:37'),
(10, 'Cebolla', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e047d7740dc59.png', 'IKU_010', 'unidad', '2025-10-03', '2025-10-03 22:02:08'),
(11, 'Zanahoria', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e047f79366d31.png', 'IKU_011', 'unidad', '2025-10-03', '2025-10-03 22:02:37'),
(12, 'Repollo', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0482c4a4fd24.png', 'IKU_012', 'unidad', '2025-10-03', '2025-10-03 22:03:34'),
(13, 'Pierna de Res', 'http://cms.restaurante.com/views/assets/files/68e04857a41e27.png', 'IKU_013', 'gramos', '2025-10-03', '2025-10-03 22:04:24'),
(14, 'Pierna+de+Cerdo', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e048780b86c40.png', 'IKU_014', 'gramos', '2025-10-03', '2025-10-03 22:04:54'),
(15, 'Pechuga+de+Pollo', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e04898c72d012.png', 'IKU_015', 'gramos', '2025-10-03', '2025-10-03 22:05:22'),
(16, 'Salsa Piña', 'http://cms.restaurante.com/views/assets/files/68e048b49bae140.png', 'IKU_016', 'gramos', '2025-10-03', '2025-10-03 22:06:51'),
(17, 'Salsa+BBQ', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e048d90783c17.png', 'IKU_017', 'gramos', '2025-10-03', '2025-10-03 22:06:35'),
(18, 'Salsa+Mayonesa', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0490c631a28.png', 'IKU_018', 'gramos', '2025-10-03', '2025-10-03 22:07:19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modules`
--

CREATE TABLE `modules` (
  `id_module` int(11) NOT NULL,
  `id_page_module` int(11) DEFAULT 0,
  `type_module` text DEFAULT NULL,
  `title_module` text DEFAULT NULL,
  `suffix_module` text DEFAULT NULL,
  `content_module` text DEFAULT NULL,
  `width_module` int(11) DEFAULT 100,
  `editable_module` int(11) DEFAULT 1,
  `date_created_module` date DEFAULT NULL,
  `date_updated_module` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `modules`
--

INSERT INTO `modules` (`id_module`, `id_page_module`, `type_module`, `title_module`, `suffix_module`, `content_module`, `width_module`, `editable_module`, `date_created_module`, `date_updated_module`) VALUES
(1, 2, 'breadcrumbs', 'Administradores', NULL, NULL, 100, 1, '2025-09-26', '2025-09-26 18:26:37'),
(2, 2, 'tables', 'admins', 'admin', '', 100, 0, '2025-09-26', '2025-09-26 21:43:00'),
(5, 5, 'breadcrumbs', 'sucursales', '', '', 100, 1, '2025-09-26', '2025-09-26 20:22:20'),
(6, 5, 'tables', 'offices', 'office', '', 100, 0, '2025-09-26', '2025-09-26 20:24:04'),
(7, 7, 'breadcrumbs', 'proveedores', '', '', 100, 1, '2025-10-03', '2025-10-03 21:11:28'),
(8, 7, 'tables', 'suppliers', 'supplier', '', 100, 1, '2025-10-03', '2025-10-03 21:13:44'),
(9, 8, 'breadcrumbs', 'ingredientes', '', '', 100, 1, '2025-10-03', '2025-10-03 21:28:19'),
(10, 8, 'tables', 'ingredients', 'ingredient', '', 100, 1, '2025-10-03', '2025-10-03 21:30:06'),
(11, 9, 'breadcrumbs', 'productos', '', '', 100, 1, '2025-10-03', '2025-10-03 22:38:01'),
(12, 9, 'tables', 'products', 'product', '', 100, 1, '2025-10-03', '2025-10-03 22:40:16'),
(13, 10, 'breadcrumbs', 'compras', '', '', 100, 1, '2025-10-04', '2025-10-04 16:13:17'),
(14, 10, 'tables', 'purchases', 'purchase', '', 100, 1, '2025-10-04', '2025-10-04 16:19:12'),
(15, 12, 'breadcrumbs', 'categorías', '', '', 100, 1, '2025-10-04', '2025-10-04 17:23:27'),
(16, 12, 'tables', 'categories', 'category', '', 100, 1, '2025-10-04', '2025-10-04 17:24:59'),
(17, 13, 'breadcrumbs', 'comidas', '', '', 100, 1, '2025-10-04', '2025-10-04 17:34:20'),
(18, 13, 'tables', 'foods', 'food', '', 100, 1, '2025-10-04', '2025-10-04 17:38:29');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `offices`
--

CREATE TABLE `offices` (
  `id_office` int(11) NOT NULL,
  `title_office` text DEFAULT NULL,
  `address_office` text DEFAULT NULL,
  `phone_office` text DEFAULT NULL,
  `date_created_office` date DEFAULT NULL,
  `date_updated_office` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `offices`
--

INSERT INTO `offices` (`id_office`, `title_office`, `address_office`, `phone_office`, `date_created_office`, `date_updated_office`) VALUES
(1, 'Sucursal+Miravalle', 'Centro+Comercial+Miravalle+Local+302', '333+333+33+33', '2025-09-26', '2025-09-26 20:25:05'),
(2, 'Sucursal+Altamira', 'Calle+34+Barrio+Altamira', '444+444+44+44', '2025-09-26', '2025-09-26 20:27:02'),
(3, 'Sucursal+Cumbres', 'Carrera+37+%23+45+-+55', '555+555+55+55', '2025-09-26', '2025-09-26 20:27:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pages`
--

CREATE TABLE `pages` (
  `id_page` int(11) NOT NULL,
  `title_page` text DEFAULT NULL,
  `url_page` text DEFAULT NULL,
  `icon_page` text DEFAULT NULL,
  `type_page` text DEFAULT NULL,
  `order_page` int(11) DEFAULT 1,
  `menu_type_page` int(11) DEFAULT 0,
  `parent_id_page` int(11) DEFAULT 0,
  `date_created_page` date DEFAULT NULL,
  `date_updated_page` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pages`
--

INSERT INTO `pages` (`id_page`, `title_page`, `url_page`, `icon_page`, `type_page`, `order_page`, `menu_type_page`, `parent_id_page`, `date_created_page`, `date_updated_page`) VALUES
(1, 'Inicio', 'inicio', 'bi bi-house-door-fill', 'modules', 1, 0, 0, '2025-09-26', '2025-09-26 18:26:37'),
(2, 'Admins', 'admins', 'bi bi-person-fill-gear', 'modules', 3, 0, 0, '2025-09-26', '2025-09-26 19:22:55'),
(3, 'Archivos', 'archivos', 'bi bi-file-earmark-image', 'custom', 4, 0, 0, '2025-09-26', '2025-09-26 19:22:55'),
(5, 'Sucursales', 'sucursales', 'bi bi-shop', 'modules', 1000, 0, 0, '2025-09-26', '2025-09-26 20:22:05'),
(6, 'Inventario', 'inventario', 'bi bi-list-columns-reverse', 'submenu', 1000, 1, 0, '2025-10-03', '2025-10-03 21:09:22'),
(7, 'Proveedores', 'proveedores', 'fa-solid fa-truck-fast', 'modules', 1000, 2, 6, '2025-10-03', '2025-10-03 21:10:33'),
(8, 'Ingredientes', 'ingredientes', 'fa-solid fa-plate-wheat', 'modules', 1000, 2, 6, '2025-10-03', '2025-10-03 21:28:05'),
(9, 'Productos', 'productos', 'fa-solid fa-lemon', 'modules', 1000, 2, 6, '2025-10-03', '2025-10-03 22:37:49'),
(10, 'Compras', 'compras', 'fa-solid fa-cart-shopping', 'modules', 1000, 2, 6, '2025-10-04', '2025-10-04 16:13:06'),
(11, 'Menú', 'menu', 'fa-solid fa-utensils', 'submenu', 1000, 1, 0, '2025-10-04', '2025-10-04 17:22:35'),
(12, 'Categorías', 'categorias', 'fa-solid fa-bowl-food', 'modules', 1000, 2, 11, '2025-10-04', '2025-10-04 17:23:14'),
(13, 'Comidas', 'comidas', 'bi bi-egg-fried', 'modules', 1000, 2, 11, '2025-10-04', '2025-10-04 17:34:06');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE `products` (
  `id_product` int(11) NOT NULL,
  `title_product` text DEFAULT NULL,
  `img_product` text DEFAULT NULL,
  `sku_product` text DEFAULT NULL,
  `type_product` text DEFAULT NULL,
  `ingredients_product` text DEFAULT '[]',
  `date_created_product` date DEFAULT NULL,
  `date_updated_product` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`id_product`, `title_product`, `img_product`, `sku_product`, `type_product`, `ingredients_product`, `date_created_product`, `date_updated_product`) VALUES
(1, 'Pan+Hamburguesa', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0511b9458a31.png', 'PKU_001', 'unidad', '%5B%5D', '2025-10-03', '2025-10-03 22:42:09'),
(2, 'Carne+Hamburguesa', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e05162e9ff942.png', 'PKU_002', 'unidad', '[{\"descripcion\":\"Pierna+de+Res\",\"sku\":\"IKU_013\",\"medida\":\"gramos\",\"cantidad\":\"100\"},{\"descripcion\":\"Pierna+de+Cerdo\",\"sku\":\"IKU_014\",\"medida\":\"gramos\",\"cantidad\":\"100\"},{\"descripcion\":\"Sal\",\"sku\":\"IKU_008\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Pimienta\",\"sku\":\"IKU_007\",\"medida\":\"gramos\",\"cantidad\":\"1\"}]', '2025-10-03', '2025-10-04 18:02:41'),
(3, 'Queso+Mozarella', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e06fa6e072f50.png', 'SKU_003', 'unidad', '%5B%5D', '2025-10-03', '2025-10-04 00:52:08'),
(4, 'Tocineta', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e06ff0010884.png', 'SKU_004', 'unidad', '%5B%5D', '2025-10-03', '2025-10-04 00:53:16'),
(5, 'Lechuga', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e070204a36552.png', 'SKU_005', 'gramos', '%5B%5D', '2025-10-03', '2025-10-04 00:54:12'),
(6, 'Salsa+de+Tomate', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e07053c561343.png', 'SKU_006', 'gramos', '%5B%5D', '2025-10-03', '2025-10-04 00:55:00'),
(7, 'Salsa+Mayonesa', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0490c631a28.png', 'SKU_007', 'gramos', '%5B%5D', '2025-10-03', '2025-10-04 00:55:22'),
(8, 'Salsa+Mostaza', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e070929165046.png', 'SKU_008', 'gramos', '%5B%5D', '2025-10-03', '2025-10-04 00:55:56'),
(9, 'Tomate', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e047b4dd23924.png', 'SKU_009', 'unidad', '%5B%5D', '2025-10-03', '2025-10-04 00:56:28'),
(10, 'Cebolla', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e047d7740dc59.png', 'SKU_010', 'unidad', '%5B%5D', '2025-10-03', '2025-10-04 00:56:48'),
(11, 'Papas+Francesa', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e070e13d8595.png', 'SKU_011', 'gramos', '%5B%5D', '2025-10-03', '2025-10-04 00:57:15'),
(12, 'Papas+Criolla', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e070fa6dfe930.png', 'SKU_012', 'gramos', '%5B%5D', '2025-10-03', '2025-10-04 00:57:39'),
(13, 'Bebida Marca Coca Cola', 'http://cms.restaurante.com/views/assets/files/68e0712161d3c9.png', 'SKU_013', 'botella', '[]', '2025-10-03', '2025-10-04 00:58:30'),
(14, 'Bebida+Marca+Postob%C3%B3n', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0714c3328452.png', 'SKU_014', 'botella', '%5B%5D', '2025-10-03', '2025-10-04 00:59:03'),
(16, 'Pollo a la BBQ', 'http://cms.restaurante.com/views/assets/files/68e0716b7259823.png', 'SKU_015', 'gramos', '[{\"descripcion\":\"Pechuga+de+Pollo^IKU_015^gramos\",\"sku\":\"IKU_015\",\"medida\":\"gramos\",\"cantidad\":\"180\"},{\"descripcion\":\"Salsa+BBQ^IKU_017^gramos\",\"sku\":\"IKU_017\",\"medida\":\"gramos\",\"cantidad\":\"3\"},{\"descripcion\":\"Sal^IKU_008^gramos\",\"sku\":\"IKU_008\",\"medida\":\"gramos\",\"cantidad\":\"1\"},{\"descripcion\":\"Pimienta^IKU_007^gramos\",\"sku\":\"IKU_007\",\"medida\":\"gramos\",\"cantidad\":\"1\"}]', '2025-10-03', '2025-10-04 01:11:26'),
(17, 'Guacamole', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0746107cf61.png', 'SKU_016', 'gramos', '%5B%7B%22descripcion%22%3A%22Aguacate%5EIKU_003%5Eunidad%22%2C%22sku%22%3A%22IKU_003%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Limones%5EIKU_005%5Eunidad%22%2C%22sku%22%3A%22IKU_005%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%221%22%7D%2C%7B%22descripcion%22%3A%22Sal%5EIKU_008%5Egramos%22%2C%22sku%22%3A%22IKU_008%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Pimienta%5EIKU_007%5Egramos%22%2C%22sku%22%3A%22IKU_007%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.1%22%7D%5D', '2025-10-03', '2025-10-04 01:12:43'),
(18, 'Ensalada+Dulce+Repollo', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e074a2a1f0a6.png', 'SKU_017', 'gramos', '%5B%7B%22descripcion%22%3A%22Repollo%5EIKU_012%5Eunidad%22%2C%22sku%22%3A%22IKU_012%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.25%22%7D%2C%7B%22descripcion%22%3A%22Zanahoria%5EIKU_011%5Eunidad%22%2C%22sku%22%3A%22IKU_011%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%220.25%22%7D%2C%7B%22descripcion%22%3A%22Sal%5EIKU_008%5Egramos%22%2C%22sku%22%3A%22IKU_008%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.5%22%7D%2C%7B%22descripcion%22%3A%22Salsa+Pi%C3%B1a%5EIKU_016%5Egramos%22%2C%22sku%22%3A%22IKU_016%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%220.25%22%7D%2C%7B%22descripcion%22%3A%22Salsa%2BMayonesa%5EIKU_018%5Egramos%22%2C%22sku%22%3A%22IKU_018%22%2C%22medida%22%3A%22gramos%22%2C%22cantidad%22%3A%221%22%7D%5D', '2025-10-03', '2025-10-04 01:14:55'),
(19, 'Aros de Cebolla Apanados', 'http://cms.restaurante.com/views/assets/files/68e0753eeedca42.png', 'SKU_018', 'unidad', '[{\"descripcion\":\"Cebolla^IKU_010^unidad\",\"sku\":\"IKU_010\",\"medida\":\"unidad\",\"cantidad\":\"10\"},{\"descripcion\":\"Harina+para+Apanar^IKU_002^gramos\",\"sku\":\"IKU_002\",\"medida\":\"gramos\",\"cantidad\":\"3\"},{\"descripcion\":\"Sal^IKU_008^gramos\",\"sku\":\"IKU_008\",\"medida\":\"gramos\",\"cantidad\":\"0.5\"},{\"descripcion\":\"Huevos^IKU_001^unidad\",\"sku\":\"IKU_001\",\"medida\":\"unidad\",\"cantidad\":\"1\"}]', '2025-10-03', '2025-10-07 21:10:59'),
(20, 'Zumo+de+lim%C3%B3n', 'http%3A%2F%2Fcms.restaurante.com%2Fviews%2Fassets%2Ffiles%2F68e0764077df60.png', 'SKU_019', 'unidad', '%5B%7B%22descripcion%22%3A%22Limones%5EIKU_005%5Eunidad%22%2C%22sku%22%3A%22IKU_005%22%2C%22medida%22%3A%22unidad%22%2C%22cantidad%22%3A%223%22%7D%5D', '2025-10-03', '2025-10-04 01:20:53');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `purchases`
--

CREATE TABLE `purchases` (
  `id_purchase` int(11) NOT NULL,
  `id_supplier_purchase` int(11) DEFAULT 0,
  `type_purchase` text DEFAULT NULL,
  `id_product_purchase` int(11) DEFAULT 0,
  `id_ingredient_purchase` int(11) DEFAULT 0,
  `measure_purchase` text DEFAULT NULL,
  `qty_purchase` double DEFAULT 0,
  `unit_cost_purchase` double DEFAULT 0,
  `cost_purchase` double DEFAULT 0,
  `stock_purchase` double DEFAULT 0,
  `id_office_purchase` int(11) DEFAULT 0,
  `date_created_purchase` date DEFAULT NULL,
  `date_updated_purchase` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `purchases`
--

INSERT INTO `purchases` (`id_purchase`, `id_supplier_purchase`, `type_purchase`, `id_product_purchase`, `id_ingredient_purchase`, `measure_purchase`, `qty_purchase`, `unit_cost_purchase`, `cost_purchase`, `stock_purchase`, `id_office_purchase`, `date_created_purchase`, `date_updated_purchase`) VALUES
(1, 1, 'producto', 1, 0, 'unidad', 500, 1, 500, 500, 1, '2025-10-04', '2025-10-04 16:22:41'),
(2, 2, 'producto', 3, 0, 'unidad', 500, 0.5, 250, 500, 1, '2025-10-04', '2025-10-04 16:52:12'),
(3, 3, 'ingrediente', 0, 13, 'gramos', 1000, 0.5, 500, 1000, 1, '2025-10-04', '2025-10-04 16:53:31'),
(4, 3, 'ingrediente', 0, 14, 'gramos', 1000, 0.5, 500, 1000, 1, '2025-10-04', '2025-10-04 16:53:45'),
(5, 3, 'ingrediente', 0, 15, 'gramos', 1000, 0.5, 500, 1000, 1, '2025-10-04', '2025-10-04 16:53:57'),
(6, 3, 'producto', 4, 0, 'unidad', 500, 0.3, 150, 500, 1, '2025-10-04', '2025-10-04 16:54:32'),
(7, 4, 'producto', 5, 0, 'gramos', 500, 0.3, 150, 500, 1, '2025-10-04', '2025-10-04 16:55:17'),
(8, 4, 'producto', 6, 0, 'gramos', 500, 0.3, 150, 500, 1, '2025-10-04', '2025-10-04 16:55:34'),
(9, 4, 'producto', 7, 0, 'gramos', 500, 0.3, 150, 500, 1, '2025-10-04', '2025-10-04 16:55:54'),
(10, 4, 'ingrediente', 0, 18, 'gramos', 500, 0.3, 150, 500, 1, '2025-10-04', '2025-10-04 16:56:19'),
(11, 4, 'producto', 8, 0, 'gramos', 500, 0.3, 150, 500, 1, '2025-10-04', '2025-10-04 16:56:46'),
(12, 4, 'producto', 9, 0, 'unidad', 500, 0.1, 50, 500, 1, '2025-10-04', '2025-10-04 16:57:29'),
(13, 4, 'producto', 10, 0, 'unidad', 500, 0.1, 50, 500, 1, '2025-10-04', '2025-10-04 16:57:42'),
(14, 4, 'producto', 11, 0, 'gramos', 500, 0.6, 300, 500, 1, '2025-10-04', '2025-10-04 16:58:14'),
(15, 4, 'producto', 12, 0, 'gramos', 500, 0.6, 300, 500, 1, '2025-10-04', '2025-10-04 16:58:28'),
(16, 4, 'producto', 13, 0, 'botella', 500, 0.16, 80, 500, 1, '2025-10-04', '2025-10-04 16:59:07'),
(17, 4, 'producto', 14, 0, 'botella', 500, 0.16, 80, 500, 1, '2025-10-04', '2025-10-04 16:59:21'),
(18, 4, 'ingrediente', 0, 1, 'unidad', 500, 0.05, 25, 500, 1, '2025-10-04', '2025-10-04 17:01:39'),
(19, 4, 'ingrediente', 0, 2, 'gramos', 500, 0.05, 25, 500, 1, '2025-10-04', '2025-10-04 17:01:51'),
(20, 4, 'ingrediente', 0, 3, 'unidad', 100, 0.25, 25, 100, 1, '2025-10-04', '2025-10-04 17:02:03'),
(21, 4, 'ingrediente', 0, 4, 'unidad', 100, 0.25, 25, 100, 1, '2025-10-04', '2025-10-04 17:02:14'),
(22, 4, 'ingrediente', 0, 5, 'unidad', 100, 0.25, 25, 100, 1, '2025-10-04', '2025-10-04 17:02:25'),
(23, 4, 'ingrediente', 0, 6, 'gramos', 100, 0.25, 25, 100, 1, '2025-10-04', '2025-10-04 17:02:38'),
(24, 4, 'ingrediente', 0, 7, 'gramos', 100, 0.25, 25, 100, 1, '2025-10-04', '2025-10-04 17:02:57'),
(25, 4, 'ingrediente', 0, 8, 'gramos', 100, 0.25, 25, 100, 1, '2025-10-04', '2025-10-04 17:03:09'),
(26, 4, 'ingrediente', 0, 9, 'unidad', 100, 0.25, 25, 100, 1, '2025-10-04', '2025-10-04 17:03:28'),
(27, 4, 'ingrediente', 0, 10, 'unidad', 100, 0.25, 25, 100, 1, '2025-10-04', '2025-10-04 17:03:42'),
(28, 4, 'ingrediente', 0, 11, 'unidad', 100, 0.25, 25, 100, 1, '2025-10-04', '2025-10-04 17:03:56'),
(29, 4, 'ingrediente', 0, 12, 'unidad', 100, 0.25, 25, 100, 1, '2025-10-04', '2025-10-04 17:04:12'),
(30, 4, 'ingrediente', 0, 16, 'gramos', 100, 0.25, 25, 100, 1, '2025-10-04', '2025-10-04 17:04:30'),
(31, 4, 'ingrediente', 0, 17, 'gramos', 100, 0.25, 25, 100, 1, '2025-10-04', '2025-10-04 17:04:44'),
(32, 1, 'producto', 1, 0, 'unidad', 500, 1, 500, 500, 2, '2025-10-04', '2025-10-04 21:22:41'),
(33, 2, 'producto', 3, 0, 'unidad', 500, 0.5, 250, 500, 2, '2025-10-04', '2025-10-04 21:52:12'),
(34, 3, 'ingrediente', 0, 13, 'gramos', 1000, 0.5, 500, 1000, 2, '2025-10-04', '2025-10-04 21:53:31'),
(35, 3, 'ingrediente', 0, 14, 'gramos', 1000, 0.5, 500, 1000, 2, '2025-10-04', '2025-10-04 21:53:45'),
(36, 3, 'ingrediente', 0, 15, 'gramos', 1000, 0.5, 500, 1000, 2, '2025-10-04', '2025-10-04 21:53:57'),
(37, 3, 'producto', 4, 0, 'unidad', 500, 0.3, 150, 500, 2, '2025-10-04', '2025-10-04 21:54:32'),
(38, 4, 'producto', 5, 0, 'gramos', 500, 0.3, 150, 500, 2, '2025-10-04', '2025-10-04 21:55:17'),
(39, 4, 'producto', 6, 0, 'gramos', 500, 0.3, 150, 500, 2, '2025-10-04', '2025-10-04 21:55:34'),
(40, 4, 'producto', 7, 0, 'gramos', 500, 0.3, 150, 500, 2, '2025-10-04', '2025-10-04 21:55:54'),
(41, 4, 'ingrediente', 0, 18, 'gramos', 500, 0.3, 150, 500, 2, '2025-10-04', '2025-10-04 21:56:19'),
(42, 4, 'producto', 8, 0, 'gramos', 500, 0.3, 150, 500, 2, '2025-10-04', '2025-10-04 21:56:46'),
(43, 4, 'producto', 9, 0, 'unidad', 500, 0.1, 50, 500, 2, '2025-10-04', '2025-10-04 21:57:29'),
(44, 4, 'producto', 10, 0, 'unidad', 500, 0.1, 50, 500, 2, '2025-10-04', '2025-10-04 21:57:42'),
(45, 4, 'producto', 11, 0, 'gramos', 500, 0.6, 300, 500, 2, '2025-10-04', '2025-10-04 21:58:14'),
(46, 4, 'producto', 12, 0, 'gramos', 500, 0.6, 300, 500, 2, '2025-10-04', '2025-10-04 21:58:28'),
(47, 4, 'producto', 13, 0, 'botella', 500, 0.16, 80, 500, 2, '2025-10-04', '2025-10-04 21:59:07'),
(48, 4, 'producto', 14, 0, 'botella', 500, 0.16, 80, 500, 2, '2025-10-04', '2025-10-04 21:59:21'),
(49, 4, 'ingrediente', 0, 1, 'unidad', 500, 0.05, 25, 500, 2, '2025-10-04', '2025-10-04 22:01:39'),
(50, 4, 'ingrediente', 0, 2, 'gramos', 500, 0.05, 25, 500, 2, '2025-10-04', '2025-10-04 22:01:51'),
(51, 4, 'ingrediente', 0, 3, 'unidad', 100, 0.25, 25, 100, 2, '2025-10-04', '2025-10-04 22:02:03'),
(52, 4, 'ingrediente', 0, 4, 'unidad', 100, 0.25, 25, 100, 2, '2025-10-04', '2025-10-04 22:02:14'),
(53, 4, 'ingrediente', 0, 5, 'unidad', 100, 0.25, 25, 100, 2, '2025-10-04', '2025-10-04 22:02:25'),
(54, 4, 'ingrediente', 0, 6, 'gramos', 100, 0.25, 25, 100, 2, '2025-10-04', '2025-10-04 22:02:38'),
(55, 4, 'ingrediente', 0, 7, 'gramos', 100, 0.25, 25, 100, 2, '2025-10-04', '2025-10-04 22:02:57'),
(56, 4, 'ingrediente', 0, 8, 'gramos', 100, 0.25, 25, 100, 2, '2025-10-04', '2025-10-04 22:03:09'),
(57, 4, 'ingrediente', 0, 9, 'unidad', 100, 0.25, 25, 100, 2, '2025-10-04', '2025-10-04 22:03:28'),
(58, 4, 'ingrediente', 0, 10, 'unidad', 100, 0.25, 25, 100, 2, '2025-10-04', '2025-10-04 22:03:42'),
(59, 4, 'ingrediente', 0, 11, 'unidad', 100, 0.25, 25, 100, 2, '2025-10-04', '2025-10-04 22:03:56'),
(60, 4, 'ingrediente', 0, 12, 'unidad', 100, 0.25, 25, 100, 2, '2025-10-04', '2025-10-04 22:04:12'),
(61, 4, 'ingrediente', 0, 16, 'gramos', 100, 0.25, 25, 100, 2, '2025-10-04', '2025-10-04 22:04:30'),
(62, 4, 'ingrediente', 0, 17, 'gramos', 100, 0.25, 25, 100, 2, '2025-10-04', '2025-10-04 22:04:44'),
(63, 1, 'producto', 1, 0, 'unidad', 500, 1, 500, 500, 3, '2025-10-04', '2025-10-04 21:22:41'),
(64, 2, 'producto', 3, 0, 'unidad', 500, 0.5, 250, 500, 3, '2025-10-04', '2025-10-04 21:52:12'),
(65, 3, 'ingrediente', 0, 13, 'gramos', 1000, 0.5, 500, 1000, 3, '2025-10-04', '2025-10-04 21:53:31'),
(66, 3, 'ingrediente', 0, 14, 'gramos', 1000, 0.5, 500, 1000, 3, '2025-10-04', '2025-10-04 21:53:45'),
(67, 3, 'ingrediente', 0, 15, 'gramos', 1000, 0.5, 500, 1000, 3, '2025-10-04', '2025-10-04 21:53:57'),
(68, 3, 'producto', 4, 0, 'unidad', 500, 0.3, 150, 500, 3, '2025-10-04', '2025-10-04 21:54:32'),
(69, 4, 'producto', 5, 0, 'gramos', 500, 0.3, 150, 500, 3, '2025-10-04', '2025-10-04 21:55:17'),
(70, 4, 'producto', 6, 0, 'gramos', 500, 0.3, 150, 500, 3, '2025-10-04', '2025-10-04 21:55:34'),
(71, 4, 'producto', 7, 0, 'gramos', 500, 0.3, 150, 500, 3, '2025-10-04', '2025-10-04 21:55:54'),
(72, 4, 'ingrediente', 0, 18, 'gramos', 500, 0.3, 150, 500, 3, '2025-10-04', '2025-10-04 21:56:19'),
(73, 4, 'producto', 8, 0, 'gramos', 500, 0.3, 150, 500, 3, '2025-10-04', '2025-10-04 21:56:46'),
(74, 4, 'producto', 9, 0, 'unidad', 500, 0.1, 50, 500, 3, '2025-10-04', '2025-10-04 21:57:29'),
(75, 4, 'producto', 10, 0, 'unidad', 500, 0.1, 50, 500, 3, '2025-10-04', '2025-10-04 21:57:42'),
(76, 4, 'producto', 11, 0, 'gramos', 500, 0.6, 300, 500, 3, '2025-10-04', '2025-10-04 21:58:14'),
(77, 4, 'producto', 12, 0, 'gramos', 500, 0.6, 300, 500, 3, '2025-10-04', '2025-10-04 21:58:28'),
(78, 4, 'producto', 13, 0, 'botella', 500, 0.16, 80, 500, 3, '2025-10-04', '2025-10-04 21:59:07'),
(79, 4, 'producto', 14, 0, 'botella', 500, 0.16, 80, 500, 3, '2025-10-04', '2025-10-04 21:59:21'),
(80, 4, 'ingrediente', 0, 1, 'unidad', 500, 0.05, 25, 500, 3, '2025-10-04', '2025-10-04 22:01:39'),
(81, 4, 'ingrediente', 0, 2, 'gramos', 500, 0.05, 25, 500, 3, '2025-10-04', '2025-10-04 22:01:51'),
(82, 4, 'ingrediente', 0, 3, 'unidad', 100, 0.25, 25, 100, 3, '2025-10-04', '2025-10-04 22:02:03'),
(83, 4, 'ingrediente', 0, 4, 'unidad', 100, 0.25, 25, 100, 3, '2025-10-04', '2025-10-04 22:02:14'),
(84, 4, 'ingrediente', 0, 5, 'unidad', 100, 0.25, 25, 100, 3, '2025-10-04', '2025-10-04 22:02:25'),
(85, 4, 'ingrediente', 0, 6, 'gramos', 100, 0.25, 25, 100, 3, '2025-10-04', '2025-10-04 22:02:38'),
(86, 4, 'ingrediente', 0, 7, 'gramos', 100, 0.25, 25, 100, 3, '2025-10-04', '2025-10-04 22:02:57'),
(87, 4, 'ingrediente', 0, 8, 'gramos', 100, 0.25, 25, 100, 3, '2025-10-04', '2025-10-04 22:03:09'),
(88, 4, 'ingrediente', 0, 9, 'unidad', 100, 0.25, 25, 100, 3, '2025-10-04', '2025-10-04 22:03:28'),
(89, 4, 'ingrediente', 0, 10, 'unidad', 100, 0.25, 25, 100, 3, '2025-10-04', '2025-10-04 22:03:42'),
(90, 4, 'ingrediente', 0, 11, 'unidad', 100, 0.25, 25, 100, 3, '2025-10-04', '2025-10-04 22:03:56'),
(91, 4, 'ingrediente', 0, 12, 'unidad', 100, 0.25, 25, 100, 3, '2025-10-04', '2025-10-04 22:04:12'),
(92, 4, 'ingrediente', 0, 16, 'gramos', 100, 0.25, 25, 100, 3, '2025-10-04', '2025-10-04 22:04:30'),
(93, 4, 'ingrediente', 0, 17, 'gramos', 100, 0.25, 25, 100, 3, '2025-10-04', '2025-10-04 22:04:44');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `suppliers`
--

CREATE TABLE `suppliers` (
  `id_supplier` int(11) NOT NULL,
  `name_supplier` text DEFAULT NULL,
  `phone_supplier` text DEFAULT NULL,
  `contact_supplier` text DEFAULT NULL,
  `email_supplier` text DEFAULT NULL,
  `description_supplier` text DEFAULT NULL,
  `date_created_supplier` date DEFAULT NULL,
  `date_updated_supplier` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `suppliers`
--

INSERT INTO `suppliers` (`id_supplier`, `name_supplier`, `phone_supplier`, `contact_supplier`, `email_supplier`, `description_supplier`, `date_created_supplier`, `date_updated_supplier`) VALUES
(1, 'Mimo+Pan', '300+343+5678', 'Jairo+Gutierrez', 'contacto@mimopan.com', 'Compra+de+panader%C3%ADa+para+hamburguesas+y+hotdogs', '2025-10-03', '2025-10-03 21:15:06'),
(2, 'Quesos la Lolita', '321 987 6543', 'Ana Solana', 'contacto@quesoslalolita.com', 'Abastecimiento de Quesos', '2025-10-03', '2025-10-03 21:17:17'),
(3, 'Carnes+Finlandia', '301+456+7890', 'Miguel+Toro', 'contacto@carnesfinlandia.com', 'Abastecimiento+de+Carnes', '2025-10-03', '2025-10-03 21:16:51'),
(4, 'Abarrotes+Los+Londo%C3%B1o', '300+234+5676', 'Sara+Ca%C3%B1as', 'contacto@abarrotes.com', 'Salsas%2C+verduras%2C+insumos%2C+especias', '2025-10-03', '2025-10-03 21:18:04');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indices de la tabla `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id_category`);

--
-- Indices de la tabla `columns`
--
ALTER TABLE `columns`
  ADD PRIMARY KEY (`id_column`);

--
-- Indices de la tabla `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id_file`);

--
-- Indices de la tabla `folders`
--
ALTER TABLE `folders`
  ADD PRIMARY KEY (`id_folder`);

--
-- Indices de la tabla `foods`
--
ALTER TABLE `foods`
  ADD PRIMARY KEY (`id_food`);

--
-- Indices de la tabla `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`id_ingredient`);

--
-- Indices de la tabla `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id_module`);

--
-- Indices de la tabla `offices`
--
ALTER TABLE `offices`
  ADD PRIMARY KEY (`id_office`);

--
-- Indices de la tabla `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id_page`);

--
-- Indices de la tabla `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id_product`);

--
-- Indices de la tabla `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id_purchase`);

--
-- Indices de la tabla `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id_supplier`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `admins`
--
ALTER TABLE `admins`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `categories`
--
ALTER TABLE `categories`
  MODIFY `id_category` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `columns`
--
ALTER TABLE `columns`
  MODIFY `id_column` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT de la tabla `files`
--
ALTER TABLE `files`
  MODIFY `id_file` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT de la tabla `folders`
--
ALTER TABLE `folders`
  MODIFY `id_folder` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `foods`
--
ALTER TABLE `foods`
  MODIFY `id_food` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT de la tabla `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `id_ingredient` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `modules`
--
ALTER TABLE `modules`
  MODIFY `id_module` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `offices`
--
ALTER TABLE `offices`
  MODIFY `id_office` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `pages`
--
ALTER TABLE `pages`
  MODIFY `id_page` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `products`
--
ALTER TABLE `products`
  MODIFY `id_product` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id_purchase` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT de la tabla `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id_supplier` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
