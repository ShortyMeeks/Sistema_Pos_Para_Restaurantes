<!--=====================================
SEARCH
======================================-->

<div class="col-12 col-lg-6">
		<div class="input-group mt-1">
			<input type="text" class="form-control rounded-start" placeholder="Search Files" id="searchFiles">
			<button type="button" class="input-group-text rounded-end"><i class="bi bi-search"></i></button>
		</div>
</div>