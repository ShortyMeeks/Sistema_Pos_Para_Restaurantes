<div class="container-fluid backgroundImage" <?php if (!empty($admin->back_admin)): ?>
	style="background-image: url(<?php echo $admin->back_admin ?>)"
<?php endif ?>>

	
	<div class="d-flex flex-wrap justify-content-center align-content-center vh-100">

		<div class="card rounded p-4 w-25 text-center" style="min-width: 320px !important;">

			<h1 class="textColor">404</h1>

			
			<h3><i class="fas fa-exclamation-triangle text-default textColor"></i> Oops! Página no encontrada.</h3>

			<p>
			No pudimos encontrar la página que estabas buscando.
			Mientras tanto, puedes <a href="/"><strong>regresar a la página de inicio</strong></a>.
			<p>

		</div>

	</div>

</div>