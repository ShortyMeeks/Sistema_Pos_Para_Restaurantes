<div class="container-fluid py-3 p-lg-4">
        
    <div class="row">
      
        <?php 

          include "breadcrumb/breadcrumb.php";
          include "content/content.php";
          include "up/up.php";

         ?>

    </div>

  </div>