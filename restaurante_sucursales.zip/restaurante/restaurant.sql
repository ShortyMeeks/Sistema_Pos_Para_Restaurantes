-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 27-09-2025 a las 02:26:16
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `restaurant`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admins`
--

CREATE TABLE `admins` (
  `id_admin` int(11) NOT NULL,
  `email_admin` text DEFAULT NULL,
  `rol_admin` text DEFAULT NULL,
  `permissions_admin` text DEFAULT '{}',
  `password_admin` text DEFAULT NULL,
  `token_admin` text DEFAULT NULL,
  `token_exp_admin` text DEFAULT NULL,
  `status_admin` int(11) DEFAULT 1,
  `title_admin` text DEFAULT NULL,
  `symbol_admin` text DEFAULT NULL,
  `font_admin` text DEFAULT NULL,
  `color_admin` text DEFAULT NULL,
  `back_admin` text DEFAULT NULL,
  `id_office_admin` int(11) DEFAULT 0,
  `scode_admin` text DEFAULT NULL,
  `chatgpt_admin` text DEFAULT NULL,
  `date_created_admin` date DEFAULT NULL,
  `date_updated_admin` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `admins`
--

INSERT INTO `admins` (`id_admin`, `email_admin`, `rol_admin`, `permissions_admin`, `password_admin`, `token_admin`, `token_exp_admin`, `status_admin`, `title_admin`, `symbol_admin`, `font_admin`, `color_admin`, `back_admin`, `id_office_admin`, `scode_admin`, `chatgpt_admin`, `date_created_admin`, `date_updated_admin`) VALUES
(1, 'superadmin@restaurante.com', 'superadmin', '{\"todo\":\"on\"}', '$2a$07$azybxcags23425sdg23sdeanQZqjaf6Birm2NvcYTNtJw24CsO5uq', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTg5MzAwNTYsImV4cCI6MTc1OTAxNjQ1NiwiZGF0YSI6eyJpZCI6IjEiLCJlbWFpbCI6InN1cGVyYWRtaW5AcmVzdGF1cmFudGUuY29tIn19.6bKMZ7ks4Q1aeEchbe0DKR6ddwk_s_ptauSxYlfNy5k', '1759016456', 1, 'REST - BAR', '<i class=\"fa-solid fa-utensils\"></i>', '<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\r\n<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\r\n<link href=\"https://fonts.googleapis.com/css2?family=Alan+Sans:wght@300..900&display=swap\" rel=\"stylesheet\">', '#830202', 'http://cms.restaurante.com/views/assets/files/68d6eafe569fd26.png', 0, NULL, NULL, '2025-09-26', '2025-09-26 23:40:56'),
(2, 'admin@restaurante.com', 'admin', '%7B%22todo%22%3A%22on%22%7D', '$2a$07$azybxcags23425sdg23sdeanQZqjaf6Birm2NvcYTNtJw24CsO5uq', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTg5MzI1MDksImV4cCI6MTc1OTAxODkwOSwiZGF0YSI6eyJpZCI6IjIiLCJlbWFpbCI6ImFkbWluQHJlc3RhdXJhbnRlLmNvbSJ9fQ.ZJxil4n9mJwgNG95riK5paXZCfjLmpbElAWh-TJIitI', '1759018909', 1, '', '', '', '', '', 0, NULL, NULL, '2025-09-26', '2025-09-27 00:21:49'),
(3, 'miravalle@restaurante.com', 'admin', '%7B%22todo%22%3A%22on%22%7D', '$2a$07$azybxcags23425sdg23sdeanQZqjaf6Birm2NvcYTNtJw24CsO5uq', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTg5MzAwMzUsImV4cCI6MTc1OTAxNjQzNSwiZGF0YSI6eyJpZCI6IjMiLCJlbWFpbCI6Im1pcmF2YWxsZUByZXN0YXVyYW50ZS5jb20ifX0.AkkBQjVSZgQEbVlo55YIrM0htkLgWweD8-C_sx9BwWU', '1759016435', 1, '', '', '', '', '', 1, NULL, NULL, '2025-09-26', '2025-09-26 23:40:35'),
(4, 'altamira@restaurante.com', 'admin', '%7B%22todo%22%3A%22on%22%7D', '$2a$07$azybxcags23425sdg23sdeanQZqjaf6Birm2NvcYTNtJw24CsO5uq', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTg5Mjc1ODQsImV4cCI6MTc1OTAxMzk4NCwiZGF0YSI6eyJpZCI6IjQiLCJlbWFpbCI6ImFsdGFtaXJhQHJlc3RhdXJhbnRlLmNvbSJ9fQ.yBlP2JtzHnwa8RAytzj6G0iPISYw3fi8OQjshUTH0lA', '1759013984', 1, '', '', '', '', '', 2, NULL, NULL, '2025-09-26', '2025-09-26 22:59:44'),
(5, 'cumbres@restaurante.com', 'admin', '%7B%22todo%22%3A%22on%22%7D', '$2a$07$azybxcags23425sdg23sdeanQZqjaf6Birm2NvcYTNtJw24CsO5uq', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTg5MjQ5NzIsImV4cCI6MTc1OTAxMTM3MiwiZGF0YSI6eyJpZCI6IjUiLCJlbWFpbCI6ImN1bWJyZXNAcmVzdGF1cmFudGUuY29tIn19.3jf0DtkPFLOd4zIxu8Cz7aKx0P31S-rvQOhUYgJtWig', '1759011372', 1, '', '', '', '', '', 3, NULL, NULL, '2025-09-26', '2025-09-26 22:16:12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `columns`
--

CREATE TABLE `columns` (
  `id_column` int(11) NOT NULL,
  `id_module_column` int(11) DEFAULT 0,
  `title_column` text DEFAULT NULL,
  `alias_column` text DEFAULT NULL,
  `type_column` text DEFAULT NULL,
  `matrix_column` text DEFAULT NULL,
  `visible_column` int(11) DEFAULT 1,
  `date_created_column` date DEFAULT NULL,
  `date_updated_column` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `columns`
--

INSERT INTO `columns` (`id_column`, `id_module_column`, `title_column`, `alias_column`, `type_column`, `matrix_column`, `visible_column`, `date_created_column`, `date_updated_column`) VALUES
(1, 2, 'email_admin', 'email', 'email', '', 1, '2025-09-26', '2025-09-26 18:26:38'),
(2, 2, 'rol_admin', 'rol', 'select', 'superadmin,admin,editor', 1, '2025-09-26', '2025-09-26 18:26:38'),
(3, 2, 'permissions_admin', 'permisos', 'object', '', 1, '2025-09-26', '2025-09-26 18:26:38'),
(4, 2, 'password_admin', 'pass', 'password', '', 0, '2025-09-26', '2025-09-26 18:26:38'),
(5, 2, 'token_admin', 'token', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:38'),
(6, 2, 'token_exp_admin', 'expiración', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:38'),
(7, 2, 'status_admin', 'estado', 'boolean', '', 1, '2025-09-26', '2025-09-26 18:26:39'),
(8, 2, 'title_admin', 'título', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:39'),
(9, 2, 'symbol_admin', 'simbolo', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:39'),
(10, 2, 'font_admin', 'tipografía', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:39'),
(11, 2, 'color_admin', 'color', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:39'),
(12, 2, 'back_admin', 'fondo', 'text', '', 0, '2025-09-26', '2025-09-26 18:26:39'),
(16, 6, 'title_office', 'Sucursal', 'text', NULL, 1, '2025-09-26', '2025-09-26 20:24:04'),
(17, 6, 'address_office', 'Dirección', 'text', NULL, 1, '2025-09-26', '2025-09-26 20:24:04'),
(18, 6, 'phone_office', 'Teléfono', 'text', NULL, 1, '2025-09-26', '2025-09-26 20:24:05'),
(19, 2, 'id_office_admin', 'Sucursal', 'relations', 'offices', 1, '2025-09-26', '2025-09-26 21:44:06');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `files`
--

CREATE TABLE `files` (
  `id_file` int(11) NOT NULL,
  `id_folder_file` int(11) DEFAULT 0,
  `name_file` text DEFAULT NULL,
  `extension_file` text DEFAULT NULL,
  `type_file` text DEFAULT NULL,
  `size_file` double DEFAULT 0,
  `link_file` text DEFAULT NULL,
  `thumbnail_vimeo_file` text DEFAULT NULL,
  `id_mailchimp_file` text DEFAULT NULL,
  `id_admin_file` int(11) DEFAULT 0,
  `date_created_file` date DEFAULT NULL,
  `date_updated_file` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `files`
--

INSERT INTO `files` (`id_file`, `id_folder_file`, `name_file`, `extension_file`, `type_file`, `size_file`, `link_file`, `thumbnail_vimeo_file`, `id_mailchimp_file`, `id_admin_file`, `date_created_file`, `date_updated_file`) VALUES
(1, 1, 'couple-over-water-suite', 'jpg', 'image/jpeg', 353336, 'http://cms.restaurante.com/views/assets/files/68d6e9c8cadd316.jpg', NULL, NULL, 1, '2025-09-26', '2025-09-26 19:30:17'),
(2, 1, 'gemini-2.5-flash-image-preview (nano-banana)_El_restaurante_ya_no', 'png', 'image/png', 1764746, 'http://cms.restaurante.com/views/assets/files/68d6eafe569fd26.png', NULL, NULL, 1, '2025-09-26', '2025-09-26 19:35:26');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `folders`
--

CREATE TABLE `folders` (
  `id_folder` int(11) NOT NULL,
  `name_folder` text DEFAULT NULL,
  `size_folder` text DEFAULT NULL,
  `total_folder` double DEFAULT 0,
  `max_upload_folder` text DEFAULT NULL,
  `url_folder` text DEFAULT NULL,
  `keys_folder` text DEFAULT NULL,
  `date_created_folder` date DEFAULT NULL,
  `date_updated_folder` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `folders`
--

INSERT INTO `folders` (`id_folder`, `name_folder`, `size_folder`, `total_folder`, `max_upload_folder`, `url_folder`, `keys_folder`, `date_created_folder`, `date_updated_folder`) VALUES
(1, 'Server', '200000000000', 2118082, '500000000', 'http://cms.restaurante.com', NULL, '2025-09-26', '2025-09-26 19:35:26');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modules`
--

CREATE TABLE `modules` (
  `id_module` int(11) NOT NULL,
  `id_page_module` int(11) DEFAULT 0,
  `type_module` text DEFAULT NULL,
  `title_module` text DEFAULT NULL,
  `suffix_module` text DEFAULT NULL,
  `content_module` text DEFAULT NULL,
  `width_module` int(11) DEFAULT 100,
  `editable_module` int(11) DEFAULT 1,
  `date_created_module` date DEFAULT NULL,
  `date_updated_module` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `modules`
--

INSERT INTO `modules` (`id_module`, `id_page_module`, `type_module`, `title_module`, `suffix_module`, `content_module`, `width_module`, `editable_module`, `date_created_module`, `date_updated_module`) VALUES
(1, 2, 'breadcrumbs', 'Administradores', NULL, NULL, 100, 1, '2025-09-26', '2025-09-26 18:26:37'),
(2, 2, 'tables', 'admins', 'admin', '', 100, 0, '2025-09-26', '2025-09-26 21:43:00'),
(5, 5, 'breadcrumbs', 'sucursales', '', '', 100, 1, '2025-09-26', '2025-09-26 20:22:20'),
(6, 5, 'tables', 'offices', 'office', '', 100, 0, '2025-09-26', '2025-09-26 20:24:04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `offices`
--

CREATE TABLE `offices` (
  `id_office` int(11) NOT NULL,
  `title_office` text DEFAULT NULL,
  `address_office` text DEFAULT NULL,
  `phone_office` text DEFAULT NULL,
  `date_created_office` date DEFAULT NULL,
  `date_updated_office` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `offices`
--

INSERT INTO `offices` (`id_office`, `title_office`, `address_office`, `phone_office`, `date_created_office`, `date_updated_office`) VALUES
(1, 'Sucursal+Miravalle', 'Centro+Comercial+Miravalle+Local+302', '333+333+33+33', '2025-09-26', '2025-09-26 20:25:05'),
(2, 'Sucursal+Altamira', 'Calle+34+Barrio+Altamira', '444+444+44+44', '2025-09-26', '2025-09-26 20:27:02'),
(3, 'Sucursal+Cumbres', 'Carrera+37+%23+45+-+55', '555+555+55+55', '2025-09-26', '2025-09-26 20:27:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pages`
--

CREATE TABLE `pages` (
  `id_page` int(11) NOT NULL,
  `title_page` text DEFAULT NULL,
  `url_page` text DEFAULT NULL,
  `icon_page` text DEFAULT NULL,
  `type_page` text DEFAULT NULL,
  `order_page` int(11) DEFAULT 1,
  `menu_type_page` int(11) DEFAULT 0,
  `parent_id_page` int(11) DEFAULT 0,
  `date_created_page` date DEFAULT NULL,
  `date_updated_page` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pages`
--

INSERT INTO `pages` (`id_page`, `title_page`, `url_page`, `icon_page`, `type_page`, `order_page`, `menu_type_page`, `parent_id_page`, `date_created_page`, `date_updated_page`) VALUES
(1, 'Inicio', 'inicio', 'bi bi-house-door-fill', 'modules', 1, 0, 0, '2025-09-26', '2025-09-26 18:26:37'),
(2, 'Admins', 'admins', 'bi bi-person-fill-gear', 'modules', 3, 0, 0, '2025-09-26', '2025-09-26 19:22:55'),
(3, 'Archivos', 'archivos', 'bi bi-file-earmark-image', 'custom', 4, 0, 0, '2025-09-26', '2025-09-26 19:22:55'),
(5, 'Sucursales', 'sucursales', 'bi bi-shop', 'modules', 1000, 0, 0, '2025-09-26', '2025-09-26 20:22:05');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indices de la tabla `columns`
--
ALTER TABLE `columns`
  ADD PRIMARY KEY (`id_column`);

--
-- Indices de la tabla `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id_file`);

--
-- Indices de la tabla `folders`
--
ALTER TABLE `folders`
  ADD PRIMARY KEY (`id_folder`);

--
-- Indices de la tabla `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id_module`);

--
-- Indices de la tabla `offices`
--
ALTER TABLE `offices`
  ADD PRIMARY KEY (`id_office`);

--
-- Indices de la tabla `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id_page`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `admins`
--
ALTER TABLE `admins`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `columns`
--
ALTER TABLE `columns`
  MODIFY `id_column` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `files`
--
ALTER TABLE `files`
  MODIFY `id_file` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `folders`
--
ALTER TABLE `folders`
  MODIFY `id_folder` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `modules`
--
ALTER TABLE `modules`
  MODIFY `id_module` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `offices`
--
ALTER TABLE `offices`
  MODIFY `id_office` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `pages`
--
ALTER TABLE `pages`
  MODIFY `id_page` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
