<!--=====================================
DRAG & DROP
======================================-->

<div class="container-fluid mb-3 px-1">
	<div class="jumbotron p-5 text-center rounded" id="dragFiles">
		<h4>¡Arrastra archivos aquí!</h4>
	</div>		
</div>