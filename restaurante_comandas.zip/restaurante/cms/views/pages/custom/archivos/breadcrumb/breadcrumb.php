<!--==============================
Breadcrumb
================================-->

<div class="col-12 position-relative">

  <div class="d-lg-flex justify-content-lg-between mt-2">

    <div class="text-capitalize h5 ps-2">Archivos</div>

    <div class="pe-0">
      <ul class="nav justify-content-lg-end">
        <li class="nav-item">
          <a class="nav-link py-0 px-0 text-dark" href="/">Inicio</a>
        </li>
        <li class="nav-item ps-3">/</li>
        <li class="nav-item">
          <a class="nav-link py-0 disabled text-capitalize" href="#">Archivos</a>
        </li> 
      </ul>
    </div>

  </div>

</div>