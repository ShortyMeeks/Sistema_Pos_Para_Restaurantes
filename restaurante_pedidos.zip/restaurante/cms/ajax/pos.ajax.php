<?php

require_once "../controllers/curl.controller.php";

class PosController{

	/*=============================================
	Administrar items de venta
	=============================================*/

	public $items_sale;
	public $id_admin;
	public $id_office;
	public $token;

	public function manageSales(){

		/*=============================================
		Traemos las ventas si están en proceso de preparación
		=============================================*/

		$url = "sales?linkTo=id_order_sale,process_sale&equalTo=".json_decode($this->items_sale)[0]->order.",Preparando";
		$method = "GET";
		$fields = array();

		$getSales = CurlController::request($url,$method,$fields);

		if($getSales->status == 200){

			$sales = $getSales->results;

			foreach ($sales as $key => $value) {
				
				/*=============================================
				Eliminar todos los items de ventas si están en proceso de preparación
				=============================================*/

				$url = "sales?id=".$value->id_sale."&nameId=id_sale&token=".$this->token."&table=admins&suffix=admin";
				$method = "DELETE";
				$fields = array();

				$deleteSales = CurlController::request($url,$method,$fields);	
			
			}

		}

		/*=============================================
		Creamos nuevamente los pedidos
		=============================================*/

		if(isset(json_decode($this->items_sale)[0]->id)){

			$countSales = 0;

			foreach (json_decode($this->items_sale) as $key => $value) {

				$url = "sales?token=".$this->token."&table=admins&suffix=admin";
				$method = "POST";
				$fields = array(
					"id_order_sale" => $value->order,
					"id_food_sale" => $value->id,
					"qty_sale" => $value->quantity,
					"subtotal_sale" => $value->price*$value->quantity,
					"status_sale" => "Pendiente",
					"id_admin_sale" => $this->id_admin,
					"id_office_sale" => $this->id_office,
					"process_sale" => "Preparando",
					"date_created_sale" => date("Y-m-d")
				);

				$createSale = CurlController::request($url,$method,$fields);

				if($createSale->status == 200){

					$countSales++;

					if($countSales == count(json_decode($this->items_sale))){

						/*=============================================
						Actualizamos la orden
						=============================================*/
						
						$url = "orders?id=".json_decode($this->items_sale)[0]->order."&nameId=id_order&token=".$this->token."&table=admins&suffix=admin";
						$method = "PUT";
						$fields = array(
							"note_order" => json_decode($this->items_sale)[0]->note
						);

						$fields = http_build_query($fields);

  						$updateOrder = CurlController::request($url,$method,$fields);

					}		

				}

			}
		
		}else{

			/*=============================================
			Actualizamos la orden
			=============================================*/
			
			$url = "orders?id=".json_decode($this->items_sale)[0]->order."&nameId=id_order&token=".$this->token."&table=admins&suffix=admin";
			$method = "PUT";
			$fields = array(
				"note_order" => json_decode($this->items_sale)[0]->note
			);

			$fields = http_build_query($fields);

			$updateOrder = CurlController::request($url,$method,$fields);

		}
	
	}

}

/*=============================================
Variables POST
=============================================*/ 

if(isset($_POST["items_sale"])){

	$ajax = new PosController();
	$ajax -> items_sale = $_POST["items_sale"];
	$ajax -> id_admin = base64_decode($_POST["id_admin"]);
	$ajax -> id_office = base64_decode($_POST["id_office"]);
	$ajax -> token = $_POST["token"];
	$ajax -> manageSales(); 

}