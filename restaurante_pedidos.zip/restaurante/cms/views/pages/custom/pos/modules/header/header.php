<div class="row mb-4">
  <div class="col-12">
    <div class="pos-header">
      <h1 class="table-title"><?php echo urldecode($_GET["titleTable"]) ?></h1>
      <div class="header-actions">
        <button class="btn btn-outline-light btn-sm me-2 rounded">
          <i class="bi bi-clock-history"></i> Historial de órdenes
        </button>
        <a href="/" class="btn btn-outline-light btn-sm rounded">
          <i class="bi bi-arrow-left"></i> Regresar a Mesas
        </a>
        <a href="/" class="btn btn-outline-light btn-sm rounded">
            <i class="bi bi-receipt"></i> Eliminar Orden
        </a>
      </div>
    </div>
  </div>
</div>