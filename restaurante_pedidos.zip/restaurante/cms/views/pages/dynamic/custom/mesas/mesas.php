<?php

if($_SESSION["admin"]->id_office_admin > 0){

	$url = "tables?linkTo=id_office_table&equalTo=".$_SESSION["admin"]->id_office_admin;
	$method = "GET";
  	$fields = array();

  	$getTables = CurlController::request($url,$method,$fields);
  	
  	if($getTables->status == 200){

		$tables = $getTables->results;
		$notFree = 0;

		foreach ($tables as $key => $value) {

			if($value->status_table != "libre"){

				$notFree++;
			}
			
		}

  	}else{

  		$tables = array();	
  	}

}else{

	echo '<script>
    setTimeout(()=>{

        $("#myOffices").modal("show");

    },100);
  </script>';

}

?>

<?php if(!empty($tables)): ?>

<link rel="stylesheet" href="/views/assets/css/mesas/mesas.css" >

<div class="col-12 mb-3 position-relative">
	
	<div class="card rounded">
		
		<div class="card-header d-flex justify-content-between align-items-center">
	      <h3 class="card-title">Gestión de Mesas</h3>
	      <div class="d-flex align-items-center">
	        <i class="fa-solid fa-chair me-2"></i>
	        <span class="badge bg-secondary"><?php echo $notFree ?>/<?php echo count($tables) ?> Mesas ocupadas</span>
	      </div>
	    </div>


	    <div class="card-body">
	    	
	    	<div class="row mb-4">
	          <div class="col-12">
	            <div class="d-flex flex-wrap gap-3 justify-content-center">
	              <div class="d-flex align-items-center">
	                <div class="legend-dot bg-success me-2"></div>
	                <span class="small">Libre</span>
	              </div>
	              <div class="d-flex align-items-center">
	                <div class="legend-dot bg-warning me-2"></div>
	                <span class="small">Ocupada</span>
	              </div>
	              <div class="d-flex align-items-center">
	                <div class="legend-dot bg-info me-2"></div>
	                <span class="small">Pagando</span>
	              </div>
	              <div class="d-flex align-items-center">
	                <div class="legend-dot bg-purple me-2"></div>
	                <span class="small">Reservada</span>
	              </div>
	            </div>
	          </div>
	        </div>

	        <div class="row g-3">
	        	
	        	<?php foreach ($tables as $key => $value): ?>

	        		<div class="col-lg-4 col-md-6">
			          <div class="table-card
			          <?php if ($value->status_table == "libre"): ?>
			          	table-free
			          <?php endif ?>
			          <?php if ($value->status_table == "ocupada"): ?>
			          	table-occupied
			          <?php endif ?>
			          <?php if ($value->status_table == "pagando"): ?>
			          	table-waiting
			          <?php endif ?>
			          <?php if ($value->status_table == "reservada"): ?>
			          	table-reserved
			          <?php endif ?>
			           ">
			            <div class="table-header">
			              <h5 class="table-number">
			              	<span class="pe-1"><?php echo urldecode($value->icon_table) ?></span> 
			              	<?php echo urldecode($value->title_table) ?>
			              </h5>
			              <span class="table-status">
			                  <?php if ($value->status_table == "libre"): ?>
			                   Libre
			                 <?php endif ?>
			                 <?php if ($value->status_table == "ocupada"): ?>
			                   Ocupada
			                 <?php endif ?>
			                 <?php if ($value->status_table == "pagando"): ?>
			                   Pagando
			                 <?php endif ?>
			                 <?php if ($value->status_table == "reservada"): ?>
			                  Reservada
			                 <?php endif ?>

			                </span>
			            </div>
			            <div class="table-info">
			              <p class="seats-info">Personas: <?php echo $value->people_table ?></p>
			            </div>
			            <div class="table-actions">
			            	<?php if ($value->status_table == "libre"): ?>
			            		<a href="/pos?idTable=<?php echo $value->id_table ?>&titleTable=<?php echo $value->title_table ?>" class="btn btn-light btn-sm w-100 seat-guests-btn">
			            			Tomar mesa
			            		</a>
				            <?php endif ?>
				            <?php if ($value->status_table == "ocupada"): ?>
			            		<a href="/pos?idTable=<?php echo $value->id_table ?>&titleTable=<?php echo $value->title_table ?>" class="btn btn-light btn-sm w-100 seat-guests-btn">
			            			Ver Orden
			            		</a>
				            <?php endif ?>
				            <?php if ($value->status_table == "reservada"): ?>
								<a href="#" class="btn btn-light btn-sm w-100 seat-guests-btn">
			            			Tomar Reserva
			            		</a>
				            <?php endif ?>
				            <?php if ($value->status_table == "pagando"): ?>
								<button class="btn btn-info btn-sm w-100 rounded">
				                    <span class="position-relative" style="bottom:2px">En Proceso de Pago</span> <div class="spinner-border spinner-border-sm"></div>
			                  	</button>
				            <?php endif ?>

			            </div>
			          </div>
			        </div>

	        	<?php endforeach ?>



	        </div>

	    </div>

	</div>



</div>

<?php else: include "views/pages/welcome/welcome.php" ?>

<?php endif ?>