<?php


if(isset($_GET["office"])){

	$_SESSION["admin"]->id_office_admin = explode("_",$_GET["office"])[0];
	$_SESSION["admin"]->title_office = explode("_",$_GET["office"])[1];
	
}

?>

<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom d-lg-flex justify-content-lg-between">
					
	<div>
		<button class="ms-2 btn btn-default border-0" id="menu-toggle">
			<i class="bi bi-layout-sidebar"></i>
		</button>
	</div>

	<div class="d-flex">

		<!--===============================
		Elegimos la sucursal
		=================================-->

		<div class="py-2 px-1">

			<?php if ($_SESSION["admin"]->id_office_admin > 0): ?>
			
				<a href="#myOffices" data-bs-toggle="modal" class="badge badge-default backColor small rounded px-3 py-2">
					<?php echo urldecode($_SESSION["admin"]->title_office) ?>
				</a>

			<?php else: ?>

				<a href="#myOffices" data-bs-toggle="modal" class="badge badge-default backColor small rounded px-3 py-2">
					Multi-Sucursal
				</a>


			<?php endif ?>

		</div>

		<div class="py-2 px-1">
			
			<a href="#" class="text-dark border rounded p-1" id="darkModeToggle">
				<i class="bi bi-sun"></i>
			</a>

		</div>

		<div class="p-2">
				
			<a href="#myProfile" data-bs-toggle="modal" style="color:inherit;">
				<i class="bi bi-person-circle"></i>
				<?php echo explode("@",$_SESSION["admin"]->email_admin)[0] ?>
			</a>

		</div>

		<div class="p-2 mx-2">
			
			<a href="/logout" class="text-dark">				
				<i class="bi bi-box-arrow-right"></i>
			</a>

		</div>

	</div>

</nav>

<?php 

if(!isset($_SESSION["admin"]->phone_office)){

	include "views/modules/modals/offices.php";

}

?>